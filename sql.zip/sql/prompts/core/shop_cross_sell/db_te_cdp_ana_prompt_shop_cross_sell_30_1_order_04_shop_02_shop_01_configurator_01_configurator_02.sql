-- Tesla owners who added products to the shop cart but didn't complete checkout, and also configured a new vehicle with more than 60 seconds time spent in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING sum(p.ShopAddToCarts) > 0
   AND sum(p.ShopPurchases) = 0
   AND uniqIfMerge(p.CfgVisitsTotal) > 0
   AND sum(p.CfgTotalTimeOnPage) > 60
