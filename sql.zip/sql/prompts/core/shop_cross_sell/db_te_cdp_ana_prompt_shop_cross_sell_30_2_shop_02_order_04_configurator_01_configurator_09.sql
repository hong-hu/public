-- Customers who completed a shop purchase, own a Tesla vehicle, and are now configuring a different model with more than 3 colors browsed in the last 30 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID, Models FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 30
  AND p.account_id IN (SELECT account_id FROM events_account_web_profile_lifetime
    GROUP BY account_id HAVING sum(ShopPurchases) > 0)
GROUP BY p.account_id, o.Models
HAVING length(groupUniqArrayMerge(p.ColorsBrowsed)) > 3
   AND ((uniqIfMerge(p.CfgVisitsM3) > 0 AND NOT has(o.Models, 'MODEL_3'))
     OR (uniqIfMerge(p.CfgVisitsMy) > 0 AND NOT has(o.Models, 'MODEL_Y'))
     OR (uniqIfMerge(p.CfgVisitsMs) > 0 AND NOT has(o.Models, 'MODEL_S'))
     OR (uniqIfMerge(p.CfgVisitsMx) > 0 AND NOT has(o.Models, 'MODEL_X'))
     OR (uniqIfMerge(p.CfgVisitsCt) > 0 AND NOT has(o.Models, 'CYBERTRUCK')))
