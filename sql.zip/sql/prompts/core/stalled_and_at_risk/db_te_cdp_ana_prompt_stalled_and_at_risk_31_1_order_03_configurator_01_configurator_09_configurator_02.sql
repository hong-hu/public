-- Who has a cancelled order, visited the configurator again in the last 7 days, browsed more than 2 colors, and spent over 3 minutes — are they reconsidering?
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalCancelledOrder > 0) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 2
   AND sum(p.CfgTotalTimeOnPage) > 180
