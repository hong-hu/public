-- Accounts with a test drive completed more than 30 days ago, opportunity still in "Follow-up and Close" stage, who returned to configure a vehicle and browsed inventory this week — warm leads going cold
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  AND ActivityCompletetionDTTM < today() - INTERVAL 30 DAY) AS td
  ON p.account_id = td.AccountID
INNER JOIN (SELECT DISTINCT AccountID FROM sales_opportunity_events FINAL
  WHERE AccountID != '' AND ProductFamily = 'Vehicle' AND Stage = 'Follow-up and Close') AS so
  ON p.account_id = so.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND sum(p.InventoryViews) > 0
