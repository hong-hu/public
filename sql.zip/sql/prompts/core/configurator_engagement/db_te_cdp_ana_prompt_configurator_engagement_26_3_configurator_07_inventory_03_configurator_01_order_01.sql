-- Who configured a Cybertruck, visited Cybertruck inventory, and had more than 3 configurator sessions but has never placed an order?
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0)
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsCt) > 0
   AND uniqIfMerge(p.CybertruckInventoryVisits) > 0
   AND uniqIfMerge(p.CfgVisitsTotal) > 3
