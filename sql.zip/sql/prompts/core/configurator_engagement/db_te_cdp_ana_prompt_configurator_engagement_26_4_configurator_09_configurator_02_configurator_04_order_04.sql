-- Customers who browsed 3 or more colors on the configurator, spent over 2 minutes, visited the pricing calculator, and don't own a Tesla vehicle
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0)
GROUP BY p.account_id
HAVING length(groupUniqArrayMerge(p.ColorsBrowsed)) >= 3
   AND sum(p.CfgTotalTimeOnPage) > 120
   AND uniqIfMerge(p.VisitedPricingCalculator) > 0
