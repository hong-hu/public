-- Who configured a Model Y, browsed more than 2 colors, spent over 3 minutes in the configurator, and also checked current offers in the last 7 days?
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsMy) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 2
   AND sum(p.CfgTotalTimeOnPage) > 180
   AND uniqIfMerge(p.CurrentOffersVisits) > 0
