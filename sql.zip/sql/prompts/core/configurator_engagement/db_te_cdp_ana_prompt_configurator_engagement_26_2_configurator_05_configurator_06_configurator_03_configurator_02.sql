-- Customers who configured both Model 3 and Model Y, compared models, and spent more than 5 minutes total on configurator pages in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsM3) > 0
   AND uniqIfMerge(p.CfgVisitsMy) > 0
   AND uniqIfMerge(p.ComparedModels) > 0
   AND sum(p.CfgTotalTimeOnPage) > 300
