-- Who has a test drive booked but not yet taken, configured a vehicle with more than 2 minutes time spent, and also browsed inventory in the last 7 days?
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')) AS td
  ON p.account_id = td.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND sum(p.CfgTotalTimeOnPage) > 120
   AND sum(p.InventoryViews) > 0
