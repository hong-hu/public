-- Non-owners who visited the test drive page, interacted with the test drive form on the website, and have a test drive activity with status "Completed" but never ordered
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed') AS td
  ON p.account_id = td.AccountID
WHERE p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0 OR TotalOrderPlaced > 0)
GROUP BY p.account_id
HAVING sum(p.TestDrivePageViews) > 0
   AND sum(p.TestDriveFormInteractions) > 0
