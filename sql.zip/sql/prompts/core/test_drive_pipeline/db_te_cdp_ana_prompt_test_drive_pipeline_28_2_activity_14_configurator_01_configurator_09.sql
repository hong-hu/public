-- Customers who completed a test drive, configured a vehicle and browsed more than 1 color, but the test drive outcome was not "Placed Order"
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  AND ActivityOutcome != 'Placed Order') AS td
  ON p.account_id = td.AccountID
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 1
