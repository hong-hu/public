-- Who configured a Model Y with more than 3 minutes time spent, has a test drive booked but not yet taken, and hasn't placed an order?
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')) AS td
  ON p.account_id = td.AccountID
WHERE p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0)
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsMy) > 0
   AND sum(p.CfgTotalTimeOnPage) > 180
