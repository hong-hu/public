-- Non-owners with a vehicle opportunity who configured both Model 3 and Model Y, compared models, and had a completed test drive activity — high-intent undecided buyers
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM sales_opportunity_events FINAL
  WHERE AccountID != '' AND ProductFamily = 'Vehicle') AS so
  ON p.account_id = so.AccountID
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed') AS td
  ON p.account_id = td.AccountID
WHERE p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0)
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsM3) > 0
   AND uniqIfMerge(p.CfgVisitsMy) > 0
   AND uniqIfMerge(p.ComparedModels) > 0
