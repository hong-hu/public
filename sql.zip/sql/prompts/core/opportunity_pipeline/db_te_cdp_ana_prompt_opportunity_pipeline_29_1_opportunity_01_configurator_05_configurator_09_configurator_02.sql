-- Customers with a vehicle opportunity who configured a Model 3, browsed more than 2 colors, and spent over 3 minutes in the configurator in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM sales_opportunity_events FINAL
  WHERE AccountID != '' AND ProductFamily = 'Vehicle') AS so
  ON p.account_id = so.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsM3) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 2
   AND sum(p.CfgTotalTimeOnPage) > 180
