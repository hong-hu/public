-- Accounts interested in Home Charging (product family) who also configured a vehicle, visited the pricing calculator, and own a Tesla — potential upsell for wall connector
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM sales_opportunity_events FINAL
  WHERE AccountID != '' AND ProductFamily = 'Home Charging') AS so
  ON p.account_id = so.AccountID
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND uniqIfMerge(p.VisitedPricingCalculator) > 0
