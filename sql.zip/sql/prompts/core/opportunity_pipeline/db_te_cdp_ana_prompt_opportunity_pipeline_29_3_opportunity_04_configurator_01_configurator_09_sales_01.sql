-- Accounts with a vehicle opportunity in "Engaged" or "Reserved" stage who visited the configurator more than 3 times, browsed colors, and checked current offers in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM sales_opportunity_events FINAL
  WHERE AccountID != '' AND ProductFamily = 'Vehicle'
  AND Stage IN ('Engaged', 'Reserved')) AS so
  ON p.account_id = so.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 3
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 0
   AND uniqIfMerge(p.CurrentOffersVisits) > 0
