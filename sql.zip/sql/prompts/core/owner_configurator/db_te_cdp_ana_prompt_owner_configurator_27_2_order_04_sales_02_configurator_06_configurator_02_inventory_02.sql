-- Non-owners who browsed FSD pages, configured a Model Y with more than 100 seconds time spent, and also checked Model Y inventory in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 7
  AND p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0)
GROUP BY p.account_id
HAVING uniqIfMerge(p.FsdPageVisits) > 0
   AND uniqIfMerge(p.CfgVisitsMy) > 0
   AND sum(p.CfgTotalTimeOnPage) > 100
   AND uniqIfMerge(p.ModelYInventoryVisits) > 0
