-- Multi-vehicle Tesla owners who compared models, configured a Cybertruck, and visited current offers in the last 30 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles >= 2) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.ComparedModels) > 0
   AND uniqIfMerge(p.CfgVisitsCt) > 0
   AND uniqIfMerge(p.CurrentOffersVisits) > 0
