-- Current Tesla owners who configured a model, browsed more than 2 colors, and spent over 5 minutes in the configurator in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 2
   AND sum(p.CfgTotalTimeOnPage) > 300
