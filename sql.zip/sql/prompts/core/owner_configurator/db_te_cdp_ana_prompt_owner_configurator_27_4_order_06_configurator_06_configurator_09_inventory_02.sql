-- Model 3 owners who configured a Model Y, browsed more than 2 colors, and visited the Model Y inventory page in the last 7 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_3')) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 7
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsMy) > 0
   AND length(groupUniqArrayMerge(p.ColorsBrowsed)) > 2
   AND uniqIfMerge(p.ModelYInventoryVisits) > 0
