-- A vehicle opportunity in the "New" stage, an order already placed, a follow-up with a rep in the last 90 days, and configurator use in the last 30 days
SELECT DISTINCT AccountID
FROM sales_opportunity_events FINAL
PREWHERE ProductFamily = 'Vehicle'
    AND Stage = 'New'
WHERE AccountID != ''
  AND AccountID IN (
      SELECT AccountID
      FROM account_order_aggregation FINAL
      WHERE TotalOrderPlaced >= 1
  )
  AND AccountID IN (
      SELECT AccountID
      FROM account_sales_activity_entity FINAL
      WHERE ActivityType = 'Follow-up' AND ActivityStatus = 'Completed'
        AND ActivityCompletetionDTTM >= today() - 90
        AND AccountID != ''
  )
  AND AccountID IN (
      SELECT DISTINCT account_id
      FROM events_account_web_profile
      PREWHERE partition_date >= today() - 30
      WHERE finalizeAggregation(CfgVisitsTotal) > 0
  )
