-- Customers who visited the Model 3 page and configured a Model 3 in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.Model3PageVisits) > 0
   AND uniqIfMerge(p.CfgVisitsM3) > 0
