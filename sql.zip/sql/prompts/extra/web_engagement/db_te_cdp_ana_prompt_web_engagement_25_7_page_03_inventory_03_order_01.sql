-- Customers who visited both the Cybertruck page and Cybertruck inventory in the last 90 days and have never ordered
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
  AND p.account_id NOT IN (SELECT AccountID FROM account_order_aggregation FINAL WHERE TotalOrderPlaced > 0)
GROUP BY p.account_id
HAVING uniqIfMerge(p.CybertruckPageVisits) > 0
   AND uniqIfMerge(p.CybertruckInventoryVisits) > 0
