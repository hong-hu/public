-- Customers who visited the homepage two or more times and looked at current offers in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.HomepageVisits) >= 2
   AND uniqIfMerge(p.CurrentOffersVisits) > 0
