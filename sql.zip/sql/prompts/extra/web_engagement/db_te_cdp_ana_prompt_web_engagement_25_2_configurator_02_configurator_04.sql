-- Customers who spent more than 5 minutes in the configurator and used the pricing calculator in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING sum(p.CfgTotalTimeOnPage) > 300
   AND uniqIfMerge(p.VisitedPricingCalculator) > 0
