-- Customers who browsed paint colors in the configurator and used the pricing calculator in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING length(groupUniqArrayMerge(p.ColorsBrowsed)) > 0
   AND uniqIfMerge(p.VisitedPricingCalculator) > 0
