-- Customers with more than 10 page views who compared models in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING sum(p.PageViews) > 10
   AND uniqIfMerge(p.ComparedModels) > 0
