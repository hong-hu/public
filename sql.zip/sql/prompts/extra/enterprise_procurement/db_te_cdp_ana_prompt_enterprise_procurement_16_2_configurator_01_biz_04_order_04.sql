-- Corporate accounts configuring in the last 90 days that do not have a vehicle yet
SELECT account_id
FROM (
    SELECT p.account_id AS account_id
    FROM events_account_web_profile AS p
    INNER JOIN (
        SELECT AccountID
        FROM account_entity FINAL
        WHERE BusinessAccountType = 'Corporate'
    ) AS ae ON p.account_id = ae.AccountID
    WHERE p.partition_date >= today() - 90
    GROUP BY p.account_id
    HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
) AS q
LEFT ANTI JOIN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0
) AS ao ON q.account_id = ao.AccountID
