-- Accounts with a signed NFA that have never ordered
SELECT DISTINCT account_id
FROM (
    SELECT AccountID AS account_id
    FROM account_entity FINAL
    PREWHERE IsNfaSigned = 1
) AS ae
LEFT ANTI JOIN (
    SELECT AccountID AS account_id
    FROM account_order_aggregation FINAL
    PREWHERE TotalOrderPlaced > 0
) AS ao USING (account_id)
