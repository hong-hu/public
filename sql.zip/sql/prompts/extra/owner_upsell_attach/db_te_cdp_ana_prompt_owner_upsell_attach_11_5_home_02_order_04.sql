-- Vehicle owners who talked with the AI assistant in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
ANY INNER JOIN (
  SELECT AccountID
  FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0
) AS o ON p.account_id = o.AccountID
PREWHERE p.partition_date >= today() - 90
  AND length(finalizeAggregation(p.AiConversationIds)) > 0
GROUP BY p.account_id
