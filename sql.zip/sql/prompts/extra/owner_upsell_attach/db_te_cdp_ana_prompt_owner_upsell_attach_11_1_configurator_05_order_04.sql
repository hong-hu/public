-- Vehicle owners who configured a Model 3, Model Y, or Cybertruck they do not already own, in the last 90 days
SELECT p.account_id
FROM (
  SELECT
    account_id,
    uniqIfMerge(CfgVisitsM3) AS v3,
    uniqIfMerge(CfgVisitsMy) AS vy,
    uniqIfMerge(CfgVisitsCt) AS vct
  FROM events_account_web_profile
  PREWHERE partition_date >= today() - 90
  GROUP BY account_id
  HAVING v3 > 0 OR vy > 0 OR vct > 0
) AS p
INNER JOIN (
  SELECT AccountID, Models
  FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0
) AS o ON p.account_id = o.AccountID
WHERE (p.v3 > 0 AND NOT has(o.Models, 'MODEL_3'))
   OR (p.vy > 0 AND NOT has(o.Models, 'MODEL_Y'))
   OR (p.vct > 0 AND NOT has(o.Models, 'CYBERTRUCK'))
