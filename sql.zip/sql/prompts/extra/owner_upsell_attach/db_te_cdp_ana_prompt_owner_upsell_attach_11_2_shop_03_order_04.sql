-- Vehicle owners who browsed the shop in the last 90 days and have never bought there
SELECT p.account_id
FROM (
  SELECT account_id
  FROM events_account_web_profile
  PREWHERE partition_date >= today() - 90
  WHERE account_id NOT IN (
      SELECT account_id
      FROM events_account_web_profile
      GROUP BY account_id
      HAVING sum(ShopPurchases) > 0
  )
  GROUP BY account_id
  HAVING sum(ShopPageViews) > 0
) AS p
ANY INNER JOIN (
  SELECT AccountID
  FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0
) AS o ON p.account_id = o.AccountID
