-- Model 3 owners who currently own at least one vehicle, without a Model Y, who configured a Model Y in the last 90 days
SELECT p.account_id
FROM (
  SELECT account_id
  FROM events_account_web_profile
  PREWHERE partition_date >= today() - 90
  WHERE finalizeAggregation(CfgVisitsMy) > 0
  GROUP BY account_id
) AS p
INNER JOIN (
  SELECT AccountID
  FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_3') AND NOT has(Models, 'MODEL_Y')
) AS o ON p.account_id = o.AccountID
