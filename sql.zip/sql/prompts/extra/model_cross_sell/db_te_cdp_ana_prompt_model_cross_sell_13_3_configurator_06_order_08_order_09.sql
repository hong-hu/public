-- Model S or Model X owners looking at a Model Y they do not own, in the last 90 days
SELECT p.account_id
FROM
(
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 90
    WHERE finalizeAggregation(CfgVisitsMy) > 0
    GROUP BY account_id
) AS p
ANY INNER JOIN
(
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0 AND hasAny(Models, ['MODEL_S', 'MODEL_X'])
      AND NOT has(Models, 'MODEL_Y')
) AS o ON p.account_id = o.AccountID
