-- Customers who completed a test drive between two weeks and three months ago, visited the website in the last 30 days, and have not ordered
SELECT DISTINCT p.account_id AS account_id
FROM events_account_web_profile AS p
PREWHERE partition_date >= today() - 30
  AND p.account_id IN
  (
      SELECT DISTINCT AccountID
      FROM account_sales_activity_entity FINAL
      WHERE ActivityCompletetionDTTM >= today() - INTERVAL 3 MONTH
        AND ActivityCompletetionDTTM < today() - INTERVAL 14 DAY
        AND ActivityStatus = 'Completed'
        AND match(ActivityType, '(?i)Test\\s*Drive')
        AND AccountID NOT IN
        (
            SELECT AccountID
            FROM account_order_aggregation FINAL
            PREWHERE AccountID IN
            (
                SELECT DISTINCT AccountID
                FROM account_sales_activity_entity FINAL
                WHERE ActivityCompletetionDTTM >= today() - INTERVAL 3 MONTH
                  AND ActivityCompletetionDTTM < today() - INTERVAL 14 DAY
                  AND ActivityStatus = 'Completed'
                  AND match(ActivityType, '(?i)Test\\s*Drive')
            )
            WHERE TotalOrderPlaced > 0
        )
  )
