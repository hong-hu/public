-- Customers with an order in progress and no website activity in the last 30 days
SELECT a.AccountID AS account_id
FROM
(
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
) AS e
RIGHT ANTI JOIN
(
    SELECT AccountID
    FROM account_order_aggregation
    FINAL
    WHERE TotalInprogressOrderd > 0
) AS a ON e.account_id = a.AccountID
