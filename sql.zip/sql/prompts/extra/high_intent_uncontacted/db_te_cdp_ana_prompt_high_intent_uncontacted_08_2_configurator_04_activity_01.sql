-- Customers who either used the pricing calculator or compared models in the last 30 days and have never completed a test drive
SELECT DISTINCT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 30
  AND account_id NOT IN (
      SELECT AccountID
      FROM account_sales_activity_entity FINAL
      WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  )
GROUP BY account_id
HAVING uniqIfMerge(VisitedPricingCalculator) > 0
    OR uniqIfMerge(ComparedModels) > 0
