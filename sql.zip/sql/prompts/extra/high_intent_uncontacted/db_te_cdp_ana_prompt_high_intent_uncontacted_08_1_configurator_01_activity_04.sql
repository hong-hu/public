-- Customers with three or more configurator sessions and more than five minutes on the page in the last 30 days, and have never had a follow-up with a rep
SELECT w.account_id AS account_id
FROM
(
    SELECT account_id
    FROM events_account_web_profile
    WHERE partition_date >= today() - 30
    GROUP BY account_id
    HAVING uniqIfMerge(CfgVisitsTotal) >= 3
       AND sum(CfgTotalTimeOnPage) > 300
) AS w
LEFT ANTI JOIN
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE ActivityType = 'Follow-up' AND ActivityStatus = 'Completed'
) AS a
ON w.account_id = a.AccountID
