-- Phone shoppers who clicked products but did not reach checkout, in the last 30 days
SELECT DISTINCT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 30
GROUP BY account_id
HAVING anyLast(LastDeviceType) IN ('iPhone', 'Android')
   AND sum(ShopProductClicks) > 0
   AND sum(ShopCheckoutSteps) = 0
