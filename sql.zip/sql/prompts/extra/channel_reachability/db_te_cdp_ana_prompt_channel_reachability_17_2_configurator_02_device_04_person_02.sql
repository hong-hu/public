-- Individual US customers who use a computer and spent more than 10 minutes in the configurator in the last 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'PERSON' AND CountryCode = 'US') AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING countIf(p.LastDeviceType IN ('Windows', 'Mac')) > 0
   AND sum(p.CfgTotalTimeOnPage) > 600
