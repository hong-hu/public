-- Individual customers we can call who have a test drive booked but not yet taken
SELECT DISTINCT ae.AccountID AS account_id
FROM (SELECT AccountID FROM account_entity FINAL
  PREWHERE AccountType = 'PERSON' AND Phone != '') AS ae
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  PREWHERE ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')
  WHERE match(ActivityType, '(?i)Test\\s*Drive')) AS td
  ON ae.AccountID = td.AccountID
