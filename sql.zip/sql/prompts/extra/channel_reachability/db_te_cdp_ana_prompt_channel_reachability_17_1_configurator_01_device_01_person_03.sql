-- Individual customers we can call who use a phone and used the configurator in the last 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'PERSON' AND Phone != '') AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING anyLast(p.LastDeviceType) IN ('iPhone', 'Android')
   AND uniqIfMerge(p.CfgVisitsTotal) > 0
