-- Customers who finished a trade-in call and visited inventory, both in the last 30 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY
    WHERE ActivityType = 'Call Request - Trade-In'
      AND ActivityStatus = 'Completed'
    GROUP BY AccountID
) AS ti ON p.account_id = ti.AccountID
PREWHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.InventoryVisits) > 0
