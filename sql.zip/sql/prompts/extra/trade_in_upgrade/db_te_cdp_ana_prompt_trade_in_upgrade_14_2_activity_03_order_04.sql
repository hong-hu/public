-- Vehicle owners who asked about a trade-in in the last 90 days
SELECT DISTINCT ti.AccountID AS account_id
FROM (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityType = 'Call Request - Trade-In'
    AND ActivityStatus = 'Completed'
    AND ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY) AS ti
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON ti.AccountID = o.AccountID
