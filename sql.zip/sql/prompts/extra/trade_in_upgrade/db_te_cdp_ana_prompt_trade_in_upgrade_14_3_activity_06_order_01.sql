-- Customers who saved a design in the last 90 days and never ordered
SELECT DISTINCT sd.AccountID AS account_id
FROM
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY
    WHERE ActivityType = 'Save Design'
      AND ActivityStatus = 'Completed'
) AS sd
LEFT ANTI JOIN
(
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0
) AS o ON sd.AccountID = o.AccountID
