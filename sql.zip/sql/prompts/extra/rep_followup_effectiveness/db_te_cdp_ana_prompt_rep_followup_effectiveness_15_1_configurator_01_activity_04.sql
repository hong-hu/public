-- Customers who had a follow-up with a rep and went back to the configurator, both in the last 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityType = 'Follow-up'
    AND ActivityStatus = 'Completed'
    AND ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY) AS fu
  ON p.account_id = fu.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
