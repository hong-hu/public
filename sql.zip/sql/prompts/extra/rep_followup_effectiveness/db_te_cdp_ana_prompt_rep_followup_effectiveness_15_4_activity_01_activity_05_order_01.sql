-- Customers who completed a test drive and met a rep in person, both in the last 90 days, and still have not ordered
SELECT m.AccountID AS account_id
FROM (
SELECT AccountID
FROM account_order_aggregation FINAL
    PREWHERE TotalOrderPlaced > 0
) AS o
RIGHT ANTI JOIN (
     SELECT AccountID
     FROM account_sales_activity_entity FINAL
         PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY
         AND ActivityStatus = 'Completed'
     WHERE if(
             ActivityType = 'In Person Meeting',
             1,
             if(
                 (positionCaseInsensitive(ActivityType, 'Test') > 0) AND (positionCaseInsensitive(ActivityType, 'Drive') > 0),
                 match(ActivityType, '(?i)Test\\s*Drive'),
                 0
             )
         )
     GROUP BY AccountID
     HAVING groupBitOr((ActivityType = 'In Person Meeting') + 1) = 3
     ) AS m ON o.AccountID = m.AccountID
