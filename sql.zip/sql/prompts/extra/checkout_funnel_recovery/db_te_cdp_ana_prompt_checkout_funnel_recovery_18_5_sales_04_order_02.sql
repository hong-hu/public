-- Customers who visited inventory in the last 30 days while an order is in progress
SELECT p.account_id
FROM (
  SELECT account_id
  FROM events_account_web_profile
  PREWHERE partition_date >= today() - 30
  GROUP BY account_id
  HAVING uniqIfMerge(InventoryVisits) > 0
) AS p
INNER JOIN (
  SELECT AccountID
  FROM account_order_aggregation FINAL
  WHERE TotalInprogressOrderd > 0
) AS o
  ON p.account_id = o.AccountID
