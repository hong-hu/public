-- Vehicle owners who started checkout and left without buying, in the last 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING sum(p.ShopCheckoutSteps) > 0
   AND sum(p.ShopPurchases) = 0
