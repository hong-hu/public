-- Individual customers we can call whose payment failed in the last two weeks
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'PERSON' AND Phone != '') AS ae
  ON p.account_id = ae.AccountID
PREWHERE p.ShopPaymentErrors > 0
WHERE p.partition_date >= today() - 14
GROUP BY p.account_id
HAVING sum(p.ShopPaymentErrors) > 0
