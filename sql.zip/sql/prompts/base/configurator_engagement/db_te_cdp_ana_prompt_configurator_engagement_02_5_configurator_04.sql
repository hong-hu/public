-- Customers who used the pricing calculator in the last 90 days
SELECT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 90
  AND finalizeAggregation(VisitedPricingCalculator) > 0
GROUP BY account_id
