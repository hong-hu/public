-- Customers who compared models in the last 7 days
SELECT account_id
FROM events_account_web_profile
PREWHERE (finalizeAggregation(ComparedModels) > 0) AND (partition_date >= today() - 7)
GROUP BY account_id
