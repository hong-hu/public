-- Customers with a test drive booked but not yet taken
SELECT DISTINCT AccountID AS account_id
FROM account_sales_activity_entity FINAL
PREWHERE ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed') AND match(ActivityType, '(?i)Test\\s*Drive')
