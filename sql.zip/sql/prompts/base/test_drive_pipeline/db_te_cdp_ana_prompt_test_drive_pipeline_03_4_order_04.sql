-- Customers who completed a test drive in the last 7 days and do not own a vehicle
SELECT DISTINCT td.AccountID AS account_id
FROM (
    SELECT DISTINCT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityStatus = 'Completed'
      AND ActivityCompletetionDTTM >= today() - INTERVAL 7 DAY
    WHERE match(ActivityType, '(?i)Test\\s*Drive')
) AS td
LEFT ANTI JOIN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles != 0
) AS o ON td.AccountID = o.AccountID
