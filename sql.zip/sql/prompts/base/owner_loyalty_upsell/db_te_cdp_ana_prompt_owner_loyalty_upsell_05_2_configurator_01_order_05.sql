-- Owners of two or more vehicles who used the configurator in the last 30 days
SELECT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 30
  AND account_id IN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles >= 2
  )
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsTotal) > 0
