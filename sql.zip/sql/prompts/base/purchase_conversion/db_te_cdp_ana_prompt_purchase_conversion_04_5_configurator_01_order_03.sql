-- Customers who cancelled an order and are back in the configurator in the last 30 days
SELECT DISTINCT w.account_id
	FROM (
		SELECT account_id
		FROM events_account_web_profile
		WHERE partition_date >= today() - 30
		GROUP BY account_id
		HAVING uniqIfMerge(CfgVisitsTotal) > 0
	) AS w
	INNER JOIN (
		SELECT AccountID
		FROM account_order_aggregation FINAL
		WHERE TotalCancelledOrder > 0
	) AS o ON w.account_id = o.AccountID
