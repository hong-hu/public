-- Customers with an order in progress
SELECT DISTINCT AccountID AS account_id
FROM account_order_aggregation
PREWHERE TotalInprogressOrderd > 0
