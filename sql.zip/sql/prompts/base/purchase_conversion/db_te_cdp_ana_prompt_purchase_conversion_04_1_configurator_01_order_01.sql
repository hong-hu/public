-- Customers who used the configurator in the last 7 days and have never ordered
SELECT v.account_id AS account_id
FROM
(
    SELECT p.account_id AS account_id
    FROM events_account_web_profile AS p
    WHERE p.partition_date >= today() - 7
    GROUP BY p.account_id
    HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
) AS v
LEFT ANTI JOIN account_order_aggregation AS o ON v.account_id = o.AccountID
