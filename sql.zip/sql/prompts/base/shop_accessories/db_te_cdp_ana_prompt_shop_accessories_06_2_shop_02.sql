-- Customers who bought in the shop in the last 30 days
SELECT account_id
	FROM events_account_web_profile
	PREWHERE (ShopPurchases > 0) AND (partition_date >= today() - 30)
	GROUP BY account_id
