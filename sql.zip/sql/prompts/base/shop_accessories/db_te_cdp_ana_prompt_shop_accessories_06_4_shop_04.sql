-- Customers who hit a payment problem in the shop in the last 30 days
SELECT account_id
FROM events_account_web_profile
PREWHERE ShopPaymentErrors > 0
WHERE partition_date >= today() - 30
GROUP BY account_id
