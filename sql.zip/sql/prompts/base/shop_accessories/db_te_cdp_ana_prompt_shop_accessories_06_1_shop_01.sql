-- Customers who added something to the shop cart in the last 7 days and did not buy
SELECT account_id
FROM events_account_web_profile
PREWHERE partition_date >= today() - 7 AND (ShopAddToCarts != 0 OR ShopPurchases != 0)
GROUP BY account_id
HAVING max(ShopAddToCarts) > 0 AND max(ShopPurchases) = 0
