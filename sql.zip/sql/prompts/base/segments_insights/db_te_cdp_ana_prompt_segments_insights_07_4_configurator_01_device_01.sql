-- Phone users who used the configurator in the last 7 days
SELECT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 7
GROUP BY account_id
HAVING countIf(LastDeviceType IN ('iPhone', 'Android')) > 0
   AND uniqIfMerge(CfgVisitsTotal) > 0
