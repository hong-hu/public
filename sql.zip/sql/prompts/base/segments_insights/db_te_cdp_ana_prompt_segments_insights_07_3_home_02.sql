-- Customers who talked with the AI assistant and used the configurator in the last 90 days
SELECT DISTINCT account_id
FROM events_account_web_profile AS p
WHERE partition_date >= today() - 90
GROUP BY account_id
HAVING length(groupUniqArrayMerge(AiConversationIds)) > 0 AND uniqIfMerge(CfgVisitsTotal) > 0
