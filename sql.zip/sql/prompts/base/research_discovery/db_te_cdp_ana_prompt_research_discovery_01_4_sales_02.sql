-- Customers who looked at Full Self-Driving and used the configurator in the last 7 days
SELECT account_id
FROM events_account_web_profile
PREWHERE partition_date >= today() - 7
     AND (finalizeAggregation(FsdPageVisits) > 0 OR finalizeAggregation(CfgVisitsTotal) > 0)
GROUP BY account_id
HAVING max(finalizeAggregation(FsdPageVisits) > 0)
   AND max(finalizeAggregation(CfgVisitsTotal) > 0)
