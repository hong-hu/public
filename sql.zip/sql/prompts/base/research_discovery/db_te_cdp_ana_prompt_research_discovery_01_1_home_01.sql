-- Customers who visited the homepage in the last 7 days
SELECT account_id
FROM events_account_web_profile
PREWHERE finalizeAggregation(HomepageVisits) > 0
WHERE partition_date >= today() - 7
GROUP BY account_id
