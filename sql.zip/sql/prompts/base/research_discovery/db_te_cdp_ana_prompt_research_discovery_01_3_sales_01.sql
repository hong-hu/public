-- Customers who looked at current offers in the last 7 days
SELECT account_id
FROM events_account_web_profile
PREWHERE partition_date >= today() - 7 AND finalizeAggregation(CurrentOffersVisits) > 0
GROUP BY account_id
