-- Individual customers in the US with at least 3 configurator sessions in the last 30 days who have not ordered
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (
    SELECT e.AccountID AS account_id
    FROM account_entity AS e FINAL
    LEFT ANTI JOIN (
        SELECT AccountID
        FROM account_order_aggregation FINAL
        WHERE TotalOrderPlaced > 0
    ) AS o ON e.AccountID = o.AccountID
    WHERE e.CountryCode = 'US' AND e.AccountType = 'PERSON'
) AS q ON p.account_id = q.account_id
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) >= 3
