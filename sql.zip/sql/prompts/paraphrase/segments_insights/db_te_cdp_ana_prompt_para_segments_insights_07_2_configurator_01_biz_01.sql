-- Business accounts that used the configurator in the last 90 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'BUSINESS') AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
