-- Customers who completed a test drive and opened the configurator more than 10 times, both in the past 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  AND ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY) AS td
  ON p.account_id = td.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 10
