-- Customers browsing inventory in the past 7 days
SELECT DISTINCT account_id
	FROM events_account_web_profile
	PREWHERE InventoryViews > 0 AND partition_date >= today() - 7
	GROUP BY account_id
