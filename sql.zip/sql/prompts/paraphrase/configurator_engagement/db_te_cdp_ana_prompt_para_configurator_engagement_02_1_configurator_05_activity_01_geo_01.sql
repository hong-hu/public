-- Customers in the US who completed a test drive, looked at the test drive page, configured a Model 3 and spent over 10 minutes in the configurator, all in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  AND ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY) AS td
  ON p.account_id = td.AccountID
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE CountryCode = 'US') AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsM3) > 0
  AND sum(p.CfgTotalTimeOnPage) > 600
  AND sum(p.TestDrivePageViews) > 0
