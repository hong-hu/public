-- Who opened the configurator in the past week but left in less than a minute?
SELECT e.account_id
FROM events_account_web_profile AS e
INNER JOIN
(
    SELECT account_id
    FROM events_account_web_profile
    WHERE partition_date >= today() - 7
    GROUP BY account_id
    HAVING sum(CfgTotalTimeOnPage) < 60
) AS t ON e.account_id = t.account_id
WHERE e.partition_date >= today() - 7
GROUP BY e.account_id
HAVING uniqIfMerge(e.CfgVisitsTotal) > 0
