-- Customers with more than 300 seconds in the configurator in the last 7 days
SELECT account_id
FROM events_account_web_profile
WHERE partition_date >= today() - 7
GROUP BY account_id
HAVING sum(CfgTotalTimeOnPage) > 300
