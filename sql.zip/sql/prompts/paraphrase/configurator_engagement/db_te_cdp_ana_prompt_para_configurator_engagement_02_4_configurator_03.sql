-- Who compared different models in the configurator during the past week?
SELECT account_id
FROM events_account_web_profile
PREWHERE (finalizeAggregation(ComparedModels) > 0) AND (partition_date >= today() - 7)
GROUP BY account_id
