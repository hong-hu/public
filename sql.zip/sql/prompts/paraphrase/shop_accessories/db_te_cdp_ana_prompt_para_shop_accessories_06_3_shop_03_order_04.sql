-- Vehicle owners who browsed the shop in the last 90 days
SELECT account_id
FROM (
  SELECT DISTINCT account_id
  FROM events_account_web_profile
  WHERE partition_date >= today() - 90 AND ShopPageViews > 0
) AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS orders
  ON p.account_id = orders.AccountID
