-- Shoppers who put items in their shop cart in the last 7 days but didn't purchase
SELECT account_id
FROM events_account_web_profile
PREWHERE partition_date >= today() - 7 AND (ShopAddToCarts != 0 OR ShopPurchases != 0)
GROUP BY account_id
HAVING max(ShopAddToCarts) > 0 AND max(ShopPurchases) = 0
