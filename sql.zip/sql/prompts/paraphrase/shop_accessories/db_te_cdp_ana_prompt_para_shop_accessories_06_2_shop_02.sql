-- Accounts that made a shop purchase in the past 30 days
SELECT account_id
	FROM events_account_web_profile
	PREWHERE (ShopPurchases > 0) AND (partition_date >= today() - 30)
	GROUP BY account_id
