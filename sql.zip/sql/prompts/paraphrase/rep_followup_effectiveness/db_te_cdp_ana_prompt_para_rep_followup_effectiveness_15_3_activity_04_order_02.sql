-- Customers with an order in progress who had a rep follow-up in the last 30 days
SELECT AccountID AS account_id
FROM account_order_aggregation FINAL
PREWHERE AccountID IN
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY
      AND ActivityType = 'Follow-up'
      AND ActivityStatus = 'Completed'
    GROUP BY AccountID
)
AND TotalInprogressOrderd > 0
GROUP BY AccountID
