-- Contactable individual customers who had a rep follow-up in the last 30 days and no website visit in the last 2 weeks
WITH candidates AS
(
    SELECT fu.AccountID AS account_id
    FROM
    (
        SELECT DISTINCT AccountID
        FROM account_sales_activity_entity FINAL
        PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY
        WHERE ActivityType = 'Follow-up'
          AND ActivityStatus = 'Completed'
    ) AS fu
    LEFT SEMI JOIN
    (
        SELECT AccountID
        FROM account_entity FINAL
        WHERE AccountType = 'PERSON'
          AND Phone != ''
    ) AS ae ON fu.AccountID = ae.AccountID
)
SELECT c.account_id
FROM candidates AS c
LEFT ANTI JOIN
(
    SELECT e.account_id
    FROM events_account_web_profile AS e
    PREWHERE e.partition_date >= today() - 14
    WHERE e.account_id IN (SELECT account_id FROM candidates)
    GROUP BY e.account_id
) AS wp ON c.account_id = wp.account_id
