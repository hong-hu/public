-- Customers who had an in-person rep meeting in the last 90 days and still haven't ordered
SELECT m.AccountID AS account_id
FROM
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY
      AND ActivityType = 'In Person Meeting'
      AND ActivityStatus = 'Completed'
    GROUP BY AccountID
) AS m
LEFT ANTI JOIN
(
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0
    GROUP BY AccountID
) AS o ON m.AccountID = o.AccountID
