-- Customers who read the test drive page in the past two weeks and have never completed a test drive or placed an order
SELECT account_id
FROM events_account_web_profile
PREWHERE TestDrivePageViews > 0 AND partition_date >= today() - 14
WHERE account_id NOT IN (
      SELECT AccountID
      FROM account_sales_activity_entity FINAL
      WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed'
  )
  AND account_id NOT IN (
      SELECT AccountID
      FROM account_order_aggregation FINAL
      WHERE TotalOrderPlaced > 0
  )
GROUP BY account_id
