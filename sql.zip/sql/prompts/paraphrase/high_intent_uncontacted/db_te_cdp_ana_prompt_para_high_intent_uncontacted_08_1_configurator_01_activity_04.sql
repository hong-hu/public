-- Customers who never had a rep follow-up but had at least three configurator sessions and over five minutes in the configurator in the last 30 days
SELECT w.account_id AS account_id
FROM
(
    SELECT account_id
    FROM events_account_web_profile
    WHERE partition_date >= today() - 30
    GROUP BY account_id
    HAVING uniqIfMerge(CfgVisitsTotal) >= 3
       AND sum(CfgTotalTimeOnPage) > 300
) AS w
LEFT ANTI JOIN
(
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE ActivityType = 'Follow-up' AND ActivityStatus = 'Completed'
) AS a
ON w.account_id = a.AccountID
