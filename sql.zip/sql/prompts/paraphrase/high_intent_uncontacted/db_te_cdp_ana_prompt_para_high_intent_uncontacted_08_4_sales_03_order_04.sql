-- People without a vehicle who were looking at inventory in the last 30 days
SELECT e.account_id
FROM (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0
) AS o
RIGHT ANTI JOIN (
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30 AND InventoryViews > 0
    GROUP BY account_id
) AS e ON o.AccountID = e.account_id
