-- Business accounts in the configurator in the last 90 days that a rep has never followed up with
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'BUSINESS') AS ae
  ON p.account_id = ae.AccountID
LEFT ANTI JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityType = 'Follow-up' AND ActivityStatus = 'Completed') AS sa
  ON p.account_id = sa.AccountID
PREWHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
