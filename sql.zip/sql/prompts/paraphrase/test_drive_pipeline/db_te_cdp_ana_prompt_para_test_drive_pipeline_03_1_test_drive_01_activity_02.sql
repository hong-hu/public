-- Customers who looked at the test drive page in the last 14 days and have neither booked nor taken a test drive
SELECT account_id
FROM events_account_web_profile
PREWHERE TestDrivePageViews > 0
WHERE partition_date >= today() - 14
  AND account_id NOT IN (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed', 'Completed')
      AND match(ActivityType, '(?i)Test\\s*Drive')
  )
GROUP BY account_id
