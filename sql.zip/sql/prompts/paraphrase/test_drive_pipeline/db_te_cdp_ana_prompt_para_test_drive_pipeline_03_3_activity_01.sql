-- Test drive completers who haven't placed an order
SELECT td.AccountID AS account_id
FROM (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityStatus = 'Completed' AND match(ActivityType, '(?i)Test\\s*Drive')
    GROUP BY AccountID
) AS td
LEFT ANTI JOIN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced != 0
) AS o ON td.AccountID = o.AccountID
