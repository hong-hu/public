-- Vehicle owners who read about FSD in the last 90 days
SELECT DISTINCT p.account_id
FROM (
  SELECT account_id
  FROM events_account_web_profile
  PREWHERE partition_date >= today() - 90
  WHERE finalizeAggregation(FsdPageVisits) > 0
) AS p
LEFT SEMI JOIN (
  SELECT AccountID
  FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0
) AS o ON p.account_id = o.AccountID
