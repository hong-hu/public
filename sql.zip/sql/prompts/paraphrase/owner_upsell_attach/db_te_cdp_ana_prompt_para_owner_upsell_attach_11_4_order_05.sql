-- Customers with more than one vehicle who finished a test drive and visited the site, both in the last 90 days
SELECT account_id
FROM events_account_web_profile
PREWHERE partition_date >= today() - 90
WHERE account_id IN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 1
      AND AccountID IN (
          SELECT AccountID
          FROM account_sales_activity_entity FINAL
          WHERE match(ActivityType, '(?i)Test\\s*Drive')
            AND ActivityStatus = 'Completed'
            AND ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY
      )
)
GROUP BY account_id
