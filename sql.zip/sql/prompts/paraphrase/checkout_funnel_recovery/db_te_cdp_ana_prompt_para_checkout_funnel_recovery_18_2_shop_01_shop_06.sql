-- Customers who, in the last 30 days, clicked on shop products but did not add anything to their cart
SELECT DISTINCT account_id
FROM events_account_web_profile
PREWHERE ShopProductClicks > 0 OR ShopAddToCarts > 0
WHERE partition_date >= today() - 30
GROUP BY account_id
HAVING sum(ShopProductClicks) > 0 AND sum(ShopAddToCarts) = 0
