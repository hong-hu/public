-- Business accounts that own a vehicle and used the configurator again in the last 30 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0) AS o
  ON p.account_id = o.AccountID
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'BUSINESS') AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
