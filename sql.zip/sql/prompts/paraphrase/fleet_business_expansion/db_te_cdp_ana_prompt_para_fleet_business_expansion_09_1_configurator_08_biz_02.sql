-- Accounts with Tesla for Business access that used the enterprise configurator in the last 90 days
SELECT p.account_id
FROM (
  SELECT account_id
  FROM events_account_web_profile
  WHERE partition_date >= today() - 90
  GROUP BY account_id
  HAVING uniqIfMerge(CfgTypeEnterprise) > 0
) AS p
INNER JOIN (
  SELECT AccountID
  FROM account_entity FINAL
  WHERE HasT4BAccess = 1
) AS ae
ON p.account_id = ae.AccountID
