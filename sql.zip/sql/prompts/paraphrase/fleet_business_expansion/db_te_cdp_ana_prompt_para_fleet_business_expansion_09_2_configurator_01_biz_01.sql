-- Business accounts that configured in the past 90 days but have never ordered
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN
(
    SELECT AccountID
    FROM account_entity FINAL
    WHERE AccountType = 'BUSINESS'
) AS ae ON p.account_id = ae.AccountID
LEFT ANTI JOIN
(
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0
) AS o ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
