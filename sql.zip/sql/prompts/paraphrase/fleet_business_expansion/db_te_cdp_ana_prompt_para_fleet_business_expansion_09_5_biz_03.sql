-- Megapack accounts that visited the website in the last 90 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE HasMegapackAccess = 1) AS ae
  ON p.account_id = ae.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
