-- Customers who completed a business account request and have had no website visits in the last 90 days
SELECT account_id
FROM
(
    SELECT DISTINCT AccountID AS account_id
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityType = 'Business Account Request'
      AND ActivityStatus = 'Completed'
) AS a
WHERE account_id NOT IN
(
    SELECT account_id
    FROM events_account_web_profile
    WHERE partition_date >= today() - 90
      AND account_id IN
      (
          SELECT AccountID
          FROM account_sales_activity_entity
          PREWHERE ActivityType = 'Business Account Request'
            AND ActivityStatus = 'Completed'
      )
)
