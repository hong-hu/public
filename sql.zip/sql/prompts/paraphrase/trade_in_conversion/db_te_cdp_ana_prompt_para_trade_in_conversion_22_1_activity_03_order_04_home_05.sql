-- Customers who completed a trade-in call, still own a vehicle, and had any web activity in the past 30 days
SELECT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
  AND account_id IN (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE ActivityType = 'Call Request - Trade-In' AND ActivityStatus = 'Completed'
      AND AccountID != ''
      AND AccountID IN (
        SELECT AccountID
        FROM account_order_aggregation FINAL
        WHERE TotalOwnedVehicles > 0
      )
  )
GROUP BY account_id
HAVING count() > 0
