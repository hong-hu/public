-- A vehicle deal in the New or Reserved stage, a booked test drive not yet taken, and any web activity in the last 30 days
SELECT DISTINCT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
WHERE account_id IN
(
    SELECT DISTINCT AccountID
    FROM sales_opportunity_events FINAL
    PREWHERE Stage IN ('New', 'Reserved')
      AND ProductFamily = 'Vehicle'
      AND AccountID != ''
    WHERE AccountID IN
    (
        SELECT AccountID
        FROM account_sales_activity_entity FINAL
        WHERE match(ActivityType, '(?i)Test\\s*Drive')
          AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')
          AND AccountID != ''
    )
)
