-- Customers who own a Roadster or a Semi and configured a Model 3 or a Model Y in the last 90 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0 AND (has(Models, 'ROADSTER') OR has(Models, 'Semi'))) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsM3) > 0
    OR uniqIfMerge(p.CfgVisitsMy) > 0
