-- Corporate accounts that had an in-person meeting with a rep in the last 90 days
SELECT DISTINCT ae.AccountID AS account_id
FROM (SELECT AccountID FROM account_entity FINAL
  WHERE BusinessAccountType = 'Corporate') AS ae
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityType = 'In Person Meeting'
    AND ActivityStatus = 'Completed'
    AND ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY) AS m
  ON ae.AccountID = m.AccountID
