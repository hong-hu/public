-- Accounts that signed an NFA but have never placed an order
SELECT DISTINCT account_id
FROM (
    SELECT AccountID AS account_id
    FROM account_entity FINAL
    PREWHERE IsNfaSigned = 1
) AS ae
LEFT ANTI JOIN (
    SELECT AccountID AS account_id
    FROM account_order_aggregation FINAL
    PREWHERE TotalOrderPlaced > 0
) AS ao USING (account_id)
