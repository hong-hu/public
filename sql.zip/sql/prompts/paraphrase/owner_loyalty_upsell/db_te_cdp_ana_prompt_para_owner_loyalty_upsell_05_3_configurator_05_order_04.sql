-- Tesla owners who configured a Model 3 and finished a test drive, both in the last 7 days
SELECT DISTINCT w.account_id
	FROM (
		SELECT account_id
		FROM events_account_web_profile
		WHERE partition_date >= today() - 7
		GROUP BY account_id
		HAVING uniqIfMerge(CfgVisitsM3) > 0
	) AS w
	INNER JOIN (
		SELECT AccountID
		FROM account_order_aggregation FINAL
		WHERE TotalOwnedVehicles > 0
	) AS o ON w.account_id = o.AccountID
	INNER JOIN (
		SELECT AccountID
		FROM account_sales_activity_entity FINAL
		WHERE match(ActivityType, '(?i)Test\\s*Drive')
		  AND ActivityStatus = 'Completed'
		  AND ActivityCompletetionDTTM >= today() - INTERVAL 7 DAY
	) AS td ON w.account_id = td.AccountID
