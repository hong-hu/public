-- People who placed an order in the past two years and have returned to the configurator in the past 90 days
SELECT DISTINCT w.account_id
	FROM (
		SELECT account_id
		FROM events_account_web_profile
		WHERE partition_date >= today() - 90
		GROUP BY account_id
		HAVING uniqIfMerge(CfgVisitsTotal) > 0
	) AS w
	INNER JOIN (
		SELECT AccountID
		FROM account_order_aggregation FINAL
		WHERE TotalOrderPlaced > 0
		  AND LastOrderPlacedDTTM >= today() - INTERVAL 2 YEAR
	) AS o ON w.account_id = o.AccountID
