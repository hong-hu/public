-- Customers who, within the last 7 days, both used the configurator and completed a test drive, and who have never ordered
SELECT w.account_id
FROM events_account_web_profile AS w
PREWHERE w.account_id IN (
    SELECT AccountID FROM account_sales_activity_entity FINAL
    WHERE ActivityStatus = 'Completed'
      AND ActivityCompletetionDTTM >= today() - INTERVAL 7 DAY
      AND match(ActivityType, '(?i)Test\\s*Drive')
  )
WHERE w.partition_date >= today() - 7
  AND w.account_id NOT IN (
    SELECT AccountID FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced > 0
      AND AccountID IN (
        SELECT AccountID FROM account_sales_activity_entity FINAL
        WHERE ActivityStatus = 'Completed'
          AND ActivityCompletetionDTTM >= today() - INTERVAL 7 DAY
          AND match(ActivityType, '(?i)Test\\s*Drive')
      )
  )
GROUP BY w.account_id
HAVING uniqIfMerge(w.CfgVisitsTotal) > 0
