-- Configurator users who have never placed an order
SELECT w.account_id
FROM (
	SELECT account_id
	FROM events_account_web_profile
	GROUP BY account_id
	HAVING uniqIfMerge(CfgVisitsTotal) > 0
) AS w
LEFT ANTI JOIN (
	SELECT AccountID
	FROM account_order_aggregation
	WHERE TotalOrderPlaced > 0
) AS o ON w.account_id = o.AccountID
