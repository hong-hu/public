-- Customers who have a cancelled order and a completed test drive and configured again in the last 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalCancelledOrder > 0) AS o
  ON p.account_id = o.AccountID
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed') AS td
  ON p.account_id = td.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
