-- Vehicle owners who haven't been on the website in the last 90 days
SELECT DISTINCT a.AccountID AS account_id
FROM
(
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOwnedVehicles > 0
) AS a
LEFT ANTI JOIN
(
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 90
) AS e ON a.AccountID = e.account_id
