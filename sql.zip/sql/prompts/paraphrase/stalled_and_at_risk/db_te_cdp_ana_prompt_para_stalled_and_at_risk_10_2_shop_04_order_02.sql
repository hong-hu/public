-- Customers with an open order who hit a payment problem in the shop in the last two weeks
SELECT p.account_id
FROM
(
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 14 AND ShopPaymentErrors != 0
    GROUP BY account_id
    HAVING sum(ShopPaymentErrors) > 0
) AS p
ANY INNER JOIN
(
    SELECT AccountID
    FROM account_order_aggregation
    FINAL
    WHERE TotalInprogressOrderd > 0
) AS o ON p.account_id = o.AccountID
