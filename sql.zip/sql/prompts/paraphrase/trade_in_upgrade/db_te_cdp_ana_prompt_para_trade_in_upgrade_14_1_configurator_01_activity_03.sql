-- Customers who finished a trade-in call and returned to the configurator, both in the past 30 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityType = 'Call Request - Trade-In'
    AND ActivityStatus = 'Completed'
    AND ActivityCompletetionDTTM >= today() - INTERVAL 30 DAY) AS ti
  ON p.account_id = ti.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.CfgVisitsTotal) > 0
