-- Model Y owners who read Model Y support pages in the last 90 days
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_Y')) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING uniqIfMerge(p.ModelYSupportVisits) > 0
