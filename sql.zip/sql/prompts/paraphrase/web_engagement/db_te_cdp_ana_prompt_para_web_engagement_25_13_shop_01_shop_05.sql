-- Customers who put accessories in their shop cart in the last 90 days but did not begin checkout in that time
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING sum(p.ShopAddToCarts) > 0
   AND sum(p.ShopCheckoutSteps) = 0
