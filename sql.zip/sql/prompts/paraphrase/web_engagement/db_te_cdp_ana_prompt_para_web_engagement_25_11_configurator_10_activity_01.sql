-- People who browsed at least two trims in the configurator in the last 90 days and have finished a test drive
SELECT p.account_id
FROM events_account_web_profile AS p
PREWHERE p.partition_date >= today() - 90
  AND p.account_id IN (SELECT AccountID FROM account_sales_activity_entity FINAL
    WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed')
GROUP BY p.account_id
HAVING length(groupUniqArrayMerge(p.ModelsBrowsed)) >= 2
