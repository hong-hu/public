-- Customers who filled in the test drive form in the last 90 days but have neither booked nor taken a test drive
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
  AND p.account_id NOT IN (SELECT AccountID FROM account_sales_activity_entity FINAL
    WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed', 'Completed'))
GROUP BY p.account_id
HAVING sum(p.TestDriveFormInteractions) > 0
