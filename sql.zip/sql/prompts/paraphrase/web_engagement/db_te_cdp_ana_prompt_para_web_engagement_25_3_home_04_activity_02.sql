-- Customers who spent over 30 minutes on the website in the last 90 days and have a test drive booked that they haven't taken
SELECT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT DISTINCT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')) AS td
  ON p.account_id = td.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING sum(p.TotalTimeSpentSeconds) > 1800
