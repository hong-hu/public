-- Customers who had at least three shop sessions in the last 90 days and have never bought anything from the shop
SELECT p.account_id
FROM events_account_web_profile AS p
WHERE p.partition_date >= today() - 90
  AND p.account_id NOT IN (
      SELECT account_id
      FROM events_account_web_profile
      GROUP BY account_id
      HAVING sum(ShopPurchases) > 0
  )
GROUP BY p.account_id
HAVING uniqIfMerge(p.ShopSessions) >= 3
