-- Customers who own a Model 3
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_3')
