-- Customers who own a Model S
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_S')
