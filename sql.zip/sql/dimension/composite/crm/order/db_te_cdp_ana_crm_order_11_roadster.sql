-- Customers who own a Roadster
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0 AND has(Models, 'ROADSTER')
