-- Customers who own a Model X
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0 AND has(Models, 'MODEL_X')
