-- Customers who own a Semi
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0 AND has(Models, 'Semi')
