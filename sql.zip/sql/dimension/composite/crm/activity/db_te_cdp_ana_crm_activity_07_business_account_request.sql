-- Customers who completed a business account request
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityType = 'Business Account Request' AND ActivityStatus = 'Completed'
