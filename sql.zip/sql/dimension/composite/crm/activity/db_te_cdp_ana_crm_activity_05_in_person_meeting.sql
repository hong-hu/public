-- Customers who met a rep in person
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityType = 'In Person Meeting' AND ActivityStatus = 'Completed'
