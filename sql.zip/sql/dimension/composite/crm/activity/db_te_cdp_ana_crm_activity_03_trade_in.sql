-- Customers who finished a trade-in call
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityType = 'Call Request - Trade-In' AND ActivityStatus = 'Completed'
