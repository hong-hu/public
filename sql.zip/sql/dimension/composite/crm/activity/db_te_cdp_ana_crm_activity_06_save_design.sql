-- Customers who saved a design
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityType = 'Save Design' AND ActivityStatus = 'Completed'
