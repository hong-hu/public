-- Customers with a test drive booked but not yet taken
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus IN ('Scheduled', 'Requested', 'Confirmed')
