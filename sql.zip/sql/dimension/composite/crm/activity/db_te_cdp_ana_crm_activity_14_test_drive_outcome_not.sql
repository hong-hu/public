-- Customers who completed a test drive whose outcome was not a given outcome
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE match(ActivityType, '(?i)Test\\s*Drive') AND ActivityStatus = 'Completed' AND ActivityOutcome != {outcome}
