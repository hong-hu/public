-- Customers who had a follow-up with a rep
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityType = 'Follow-up' AND ActivityStatus = 'Completed'
