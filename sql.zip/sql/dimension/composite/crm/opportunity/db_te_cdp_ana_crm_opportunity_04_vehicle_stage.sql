-- Customers with a vehicle opportunity in a stage
SELECT AccountID FROM sales_opportunity_events FINAL
WHERE AccountID != '' AND ProductFamily = 'Vehicle' AND Stage = {stage}
