-- Individual customers we can call
SELECT AccountID FROM account_entity FINAL
WHERE AccountType = 'PERSON' AND Phone != ''
