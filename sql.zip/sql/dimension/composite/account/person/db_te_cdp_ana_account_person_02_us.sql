-- Individual (person) customers in the US: only when the question says individual or person
SELECT AccountID FROM account_entity FINAL
WHERE AccountType = 'PERSON' AND CountryCode = 'US'
