-- Corporate accounts
SELECT AccountID FROM account_entity FINAL
WHERE BusinessAccountType = 'Corporate'
