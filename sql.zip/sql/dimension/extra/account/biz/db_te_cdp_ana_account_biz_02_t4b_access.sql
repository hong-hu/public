-- Accounts with Tesla for Business access
SELECT AccountID FROM account_entity FINAL
WHERE HasT4BAccess = 1
