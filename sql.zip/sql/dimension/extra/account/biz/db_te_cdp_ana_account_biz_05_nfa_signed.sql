-- Accounts with a signed NFA
SELECT AccountID FROM account_entity FINAL
WHERE IsNfaSigned = 1
