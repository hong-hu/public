-- Accounts with Megapack access
SELECT AccountID FROM account_entity FINAL
WHERE HasMegapackAccess = 1
