-- Individual (person) customers, any country; for individual US customers use account_person_02
SELECT AccountID FROM account_entity FINAL
WHERE AccountType = 'PERSON'
