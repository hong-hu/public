-- Customers with a Home Charging opportunity
SELECT AccountID FROM sales_opportunity_events FINAL
WHERE AccountID != '' AND ProductFamily = 'Home Charging'
