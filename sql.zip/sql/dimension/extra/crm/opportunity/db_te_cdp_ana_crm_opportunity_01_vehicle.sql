-- Customers with a vehicle opportunity
SELECT AccountID FROM sales_opportunity_events FINAL
WHERE AccountID != '' AND ProductFamily = 'Vehicle'
