-- Customers who own more than one vehicle
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 1
