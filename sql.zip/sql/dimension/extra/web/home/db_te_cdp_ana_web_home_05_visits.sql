-- Customers who were on / visited the website at all (any page); for 'homepage' use web_home_01
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING count() > 0
