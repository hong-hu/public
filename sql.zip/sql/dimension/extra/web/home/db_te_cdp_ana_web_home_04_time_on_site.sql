-- Customers who spent time on the website (time on site, not page views)
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(TotalTimeSpentSeconds) > 0
