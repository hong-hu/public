-- Customers who viewed pages on the website: 'page views' means this
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(PageViews) > 0
