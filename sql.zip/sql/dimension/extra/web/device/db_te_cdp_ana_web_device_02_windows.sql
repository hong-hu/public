-- Customers on a Windows computer; for 'a computer' (Windows or Mac) use web_device_04
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING countIf(LastDeviceType = 'Windows') > 0
