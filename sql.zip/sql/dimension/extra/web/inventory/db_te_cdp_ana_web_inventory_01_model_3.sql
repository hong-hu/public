-- Customers who visited Model 3 inventory
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(Model3InventoryVisits) > 0
