-- Customers who visited Cybertruck inventory
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CybertruckInventoryVisits) > 0
