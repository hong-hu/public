-- Customers who visited Model Y inventory
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(ModelYInventoryVisits) > 0
