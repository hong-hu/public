-- Customers who configured a Model S
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsMs) > 0
