-- Customers who configured a Model X
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsMx) > 0
