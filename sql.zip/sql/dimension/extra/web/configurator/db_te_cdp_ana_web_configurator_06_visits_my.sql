-- Customers who configured a Model Y
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsMy) > 0
