-- Customers who used the enterprise configurator
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgTypeEnterprise) > 0
