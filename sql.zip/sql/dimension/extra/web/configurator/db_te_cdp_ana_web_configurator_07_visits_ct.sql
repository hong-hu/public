-- Customers who configured a Cybertruck
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsCt) > 0
