-- Customers who browsed trims in the configurator
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING length(groupUniqArrayMerge(ModelsBrowsed)) > 0
