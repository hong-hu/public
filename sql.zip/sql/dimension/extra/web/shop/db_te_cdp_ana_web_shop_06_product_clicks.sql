-- Customers who clicked products in the shop
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(ShopProductClicks) > 0
