-- Customers who had shop sessions
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(ShopSessions) > 0
