-- Customers who looked at the Wall Connector or Mobile Connector in the shop
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING hasAny(groupUniqArrayMerge(ShopProductsViewed), ['Wall Connector', 'Mobile Connector'])
