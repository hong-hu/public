-- Customers who first arrived from the 2026 Model Y launch
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING argMinMerge(FirstCampaignName) = '2026_model_y_launch'
