-- Customers who first arrived from a paid ad
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING argMinMerge(FirstCampaignMedium) = 'cpc'
