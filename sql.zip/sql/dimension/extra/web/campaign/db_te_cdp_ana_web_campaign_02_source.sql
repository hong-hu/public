-- Customers who first arrived from Google
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING argMinMerge(FirstCampaignSource) = 'google'
