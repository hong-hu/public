-- Customers who interacted with the test drive form
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(TestDriveFormInteractions) > 0
