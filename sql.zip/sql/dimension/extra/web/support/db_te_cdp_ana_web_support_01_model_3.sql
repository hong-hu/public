-- Customers who visited Model 3 support pages
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(Model3SupportVisits) > 0
