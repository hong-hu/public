-- Customers who visited Model Y support pages
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(ModelYSupportVisits) > 0
