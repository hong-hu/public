-- Customers who visited inventory: 'visited inventory' means this (inventory visits / sessions)
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(InventoryVisits) > 0
