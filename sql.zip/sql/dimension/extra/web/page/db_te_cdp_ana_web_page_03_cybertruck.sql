-- Customers who visited the Cybertruck page
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CybertruckPageVisits) > 0
