-- Customers who visited the Model Y page
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(ModelYPageVisits) > 0
