-- Customers with an order in progress
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalInprogressOrderd > 0
