-- Customers who ordered
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOrderPlaced > 0
