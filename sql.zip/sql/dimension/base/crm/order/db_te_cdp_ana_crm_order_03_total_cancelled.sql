-- Customers who cancelled an order
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalCancelledOrder > 0
