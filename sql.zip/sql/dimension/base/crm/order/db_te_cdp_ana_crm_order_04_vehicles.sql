-- Customers who already own a vehicle
SELECT AccountID FROM account_order_aggregation FINAL
WHERE TotalOwnedVehicles > 0
