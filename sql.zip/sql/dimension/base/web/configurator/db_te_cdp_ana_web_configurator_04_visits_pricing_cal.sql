-- Customers who used the pricing calculator
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(VisitedPricingCalculator) > 0
