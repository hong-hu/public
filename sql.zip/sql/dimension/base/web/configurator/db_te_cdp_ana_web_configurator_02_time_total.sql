-- Customers who spent more than 10 minutes in the configurator
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(CfgTotalTimeOnPage) > 600
