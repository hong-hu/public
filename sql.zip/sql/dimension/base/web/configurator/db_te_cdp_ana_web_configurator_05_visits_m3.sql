-- Customers who configured a Model 3
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsM3) > 0
