-- Customers on a mobile phone (phone users)
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING countIf(LastDeviceType IN ('iPhone', 'Android')) > 0
