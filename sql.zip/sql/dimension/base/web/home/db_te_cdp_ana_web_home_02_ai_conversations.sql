-- Customers who talked with the AI assistant
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING length(groupUniqArrayMerge(AiConversationIds)) > 0
