-- Customers who visited the homepage: 'homepage' means this (homepage only, not the whole site)
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(HomepageVisits) > 0
