-- Customers who looked at the test drive page
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(TestDrivePageViews) > 0
