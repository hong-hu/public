-- Customers who added something to the shop cart
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(ShopAddToCarts) > 0
