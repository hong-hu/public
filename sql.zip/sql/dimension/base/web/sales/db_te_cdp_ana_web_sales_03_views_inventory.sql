-- Customers who looked at / were looking at / browsed / viewed inventory pages (inventory page views); for 'visited inventory' use web_sales_04
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING sum(InventoryViews) > 0
