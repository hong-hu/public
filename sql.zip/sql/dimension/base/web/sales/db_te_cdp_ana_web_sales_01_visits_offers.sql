-- Customers who looked at current offers
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(CurrentOffersVisits) > 0
