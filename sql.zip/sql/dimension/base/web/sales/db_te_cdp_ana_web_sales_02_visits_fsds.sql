-- Customers who looked at Full Self-Driving
SELECT account_id FROM events_account_web_profile
GROUP BY account_id
HAVING uniqIfMerge(FsdPageVisits) > 0
