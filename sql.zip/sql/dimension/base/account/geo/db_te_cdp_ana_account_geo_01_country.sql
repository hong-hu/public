-- Accounts in a country, any account type: 'US customers' means this with country US
SELECT AccountID FROM account_entity FINAL
WHERE CountryCode = {country}
