-- Business accounts
SELECT AccountID FROM account_entity FINAL
WHERE AccountType = 'BUSINESS'
