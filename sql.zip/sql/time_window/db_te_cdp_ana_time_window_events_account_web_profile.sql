-- Time window of events_account_web_profile
SELECT account_id FROM events_account_web_profile
WHERE partition_date >= today() - INTERVAL {n} {unit}
