-- Time window of account_order_aggregation
SELECT AccountID FROM account_order_aggregation FINAL
WHERE LastOrderPlacedDTTM >= today() - INTERVAL {n} {unit}
