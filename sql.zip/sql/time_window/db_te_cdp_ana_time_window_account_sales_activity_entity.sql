-- Time window of account_sales_activity_entity
SELECT AccountID FROM account_sales_activity_entity FINAL
WHERE ActivityCompletetionDTTM >= today() - INTERVAL {n} {unit}
