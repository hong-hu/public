-- Customers who visited the configurator in the last 30 days, have ever completed a trade-in call, have an order that includes a trade-in, and have a car still with them
WITH
c AS
(
    SELECT DISTINCT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityType = 'Call Request - Trade-In'
        AND ActivityStatus = 'Completed'
    WHERE AccountID != ''
),
co AS
(
    SELECT DISTINCT AccountID
    FROM account_orders_entity FINAL
    PREWHERE SubStatus = 'TRADE_IN'
        AND AccountID IN (SELECT AccountID FROM c)
),
cov AS
(
    SELECT DISTINCT AccountID
    FROM vehicle_asset_entity FINAL
    PREWHERE ISActive = 1
        AND AccountID IN (SELECT AccountID FROM co)
)
SELECT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
    AND account_id IN (SELECT AccountID FROM cov)
GROUP BY account_id
HAVING uniqIfMerge(CfgVisitsTotal) > 0
