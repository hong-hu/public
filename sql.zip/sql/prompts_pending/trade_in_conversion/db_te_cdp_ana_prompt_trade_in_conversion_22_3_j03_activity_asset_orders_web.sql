-- Customers who finished a trade-in call, have a delivered car, and are comparing models or pricing again in the last 30 days
SELECT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
WHERE account_id IN (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityType = 'Call Request - Trade-In'
      AND ActivityStatus = 'Completed'
    WHERE AccountID != ''
      AND AccountID IN (
          SELECT AccountID
          FROM vehicle_asset_entity FINAL
          PREWHERE Status = 'DELIVERED'
      )
      AND AccountID IN (
          SELECT AccountID
          FROM account_orders_entity FINAL
          PREWHERE Status = 'DELIVERED'
      )
)
GROUP BY account_id
HAVING uniqIfMerge(ComparedModels) > 0
    OR uniqIfMerge(VisitedPricingCalculator) > 0
