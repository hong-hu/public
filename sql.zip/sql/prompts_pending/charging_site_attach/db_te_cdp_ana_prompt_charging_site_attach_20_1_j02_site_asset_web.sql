-- Delivered owners whose home charging install has only just started, and who visited the site in the last 30 days
SELECT DISTINCT AccountID
FROM (
    SELECT AccountID
    FROM sites_entity FINAL
    PREWHERE Status = 'Site Initiated' AND ProjectType = 'Residential'
) AS s
ANY INNER JOIN (
    SELECT AccountID
    FROM vehicle_asset_entity FINAL
    PREWHERE Status = 'DELIVERED'
) AS v USING (AccountID)
ANY INNER JOIN (
    SELECT account_id AS AccountID
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
    WHERE PageViews > 0
    GROUP BY account_id
) AS e USING (AccountID)
