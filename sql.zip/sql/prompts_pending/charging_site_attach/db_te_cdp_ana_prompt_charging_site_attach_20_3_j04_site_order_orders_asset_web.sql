-- Customers with more than one charging site, a car they own, a delivered order, and a site visit in the last 30 days
SELECT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
  AND account_id IN (
    SELECT AccountID
    FROM sites_entity FINAL
    WHERE AccountID IN (
        SELECT AccountID
        FROM account_order_aggregation FINAL
        WHERE TotalOwnedVehicles > 0
    )
      AND AccountID IN (
        SELECT AccountID
        FROM account_orders_entity FINAL
        WHERE Status = 'DELIVERED'
    )
      AND AccountID IN (
        SELECT AccountID
        FROM vehicle_asset_entity FINAL
        WHERE ISActive = 1
    )
    GROUP BY AccountID
    HAVING uniqExact(SiteID) >= 2
)
GROUP BY account_id
HAVING sum(PageViews) > 0
