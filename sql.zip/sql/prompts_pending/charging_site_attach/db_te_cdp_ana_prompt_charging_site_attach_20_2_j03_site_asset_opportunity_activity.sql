-- Customers with two or more delivered vehicles, a commercial charging or energy site already running, a home charging deal on the books, and a rep working it in the last 6 months
SELECT AccountID
FROM vehicle_asset_entity FINAL
PREWHERE Status = 'DELIVERED'
    AND AccountID IN
    (
        SELECT AccountID
        FROM account_sales_activity_entity FINAL
        WHERE EventTime >= today() - 180
            AND AccountID != ''
            AND AccountID IN
            (
                SELECT s.AccountID
                FROM
                (
                    SELECT AccountID
                    FROM sites_entity FINAL
                    PREWHERE Status IN ('Open', 'Operating')
                        AND ProjectType IN ('CommercialCharging', 'CommercialEnergy')
                    GROUP BY AccountID
                ) AS s
                INNER JOIN
                (
                    SELECT AccountID
                    FROM sales_opportunity_events FINAL
                    PREWHERE ProductFamily = 'Home Charging'
                        AND AccountID != ''
                    GROUP BY AccountID
                ) AS o ON s.AccountID = o.AccountID
            )
        GROUP BY AccountID
    )
GROUP BY AccountID
HAVING count() >= 2
