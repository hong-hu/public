-- Customers who first arrived from Google and completed a test drive in the last 90 days
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE match(ActivityType, '(?i)Test\\s*Drive')
    AND ActivityStatus = 'Completed'
    AND ActivityCompletetionDTTM >= today() - INTERVAL 90 DAY) AS td
  ON p.account_id = td.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING argMinMerge(p.FirstCampaignSource) = 'google'
