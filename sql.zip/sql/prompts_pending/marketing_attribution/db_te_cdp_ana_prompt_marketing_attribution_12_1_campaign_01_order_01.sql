-- Customers who first arrived from the 2026 Model Y launch and ordered within the year
SELECT DISTINCT p.account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOrderPlaced > 0
    AND LastOrderPlacedDTTM >= today() - INTERVAL 1 YEAR) AS o
  ON p.account_id = o.AccountID
WHERE p.partition_date >= today() - 90
GROUP BY p.account_id
HAVING argMinMerge(p.FirstCampaignName) = '2026_model_y_launch'
