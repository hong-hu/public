-- Customers with two or more orders, at least one delivered, back in the configurator in the last 30 days
SELECT ag.AccountID
FROM (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    WHERE TotalOrderPlaced >= 2
) AS ag
LEFT SEMI JOIN (
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
        AND finalizeAggregation(CfgVisitsTotal) > 0
) AS wp ON wp.account_id = ag.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_orders_entity FINAL
    PREWHERE Status = 'DELIVERED'
) AS ao ON ao.AccountID = ag.AccountID
