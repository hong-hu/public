-- Customers with three or more orders, more than one model, two delivered cars, and inventory views in the last 30 days
SELECT AccountID
FROM account_order_aggregation FINAL
PREWHERE TotalOrderPlaced >= 3
WHERE length(Models) >= 2
  AND AccountID IN (
    SELECT AccountID
    FROM vehicle_asset_entity FINAL
    PREWHERE Status = 'DELIVERED'
    GROUP BY AccountID
    HAVING count() >= 2
  )
  AND AccountID IN (
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
      AND InventoryViews > 0
    GROUP BY account_id
  )
