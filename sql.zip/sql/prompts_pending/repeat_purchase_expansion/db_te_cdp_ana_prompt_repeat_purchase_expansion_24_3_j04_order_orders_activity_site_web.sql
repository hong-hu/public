-- Repeat buyers who still own a car, have a delivered order, heard from a rep in the last 6 months, have a home charging site, and visited the website in the last 30 days
SELECT DISTINCT ag.AccountID
FROM (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    PREWHERE TotalOrderPlaced >= 2
    WHERE TotalOwnedVehicles > 0
) AS ag
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_orders_entity FINAL
    PREWHERE Status = 'DELIVERED'
) AS ao ON ao.AccountID = ag.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE EventTime >= today() - 180
        AND AccountID != ''
) AS sa ON sa.AccountID = ag.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM sites_entity FINAL
    PREWHERE ProjectType IN ('Residential', 'HomeCharging')
) AS se ON se.AccountID = ag.AccountID
LEFT SEMI JOIN (
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
    GROUP BY account_id
    HAVING sum(PageViews) > 0
) AS wp ON wp.account_id = ag.AccountID
