-- A new or reserved vehicle opportunity, a delivered car, a delivered order, a completed rep visit, and a website visit in the last 30 days
SELECT DISTINCT so.AccountID
FROM (
    SELECT DISTINCT AccountID
    FROM sales_opportunity_events FINAL
    WHERE AccountID != ''
      AND Stage IN ('New', 'Reserved')
) AS so
INNER JOIN (
    SELECT DISTINCT AccountID
    FROM vehicle_asset_entity FINAL
    WHERE Status = 'DELIVERED'
) AS va ON va.AccountID = so.AccountID
INNER JOIN (
    SELECT DISTINCT AccountID
    FROM account_orders_entity FINAL
    WHERE Status = 'DELIVERED'
) AS ao ON ao.AccountID = so.AccountID
INNER JOIN (
    SELECT DISTINCT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE AccountID != ''
      AND ActivityStatus = 'Completed'
) AS sa ON sa.AccountID = so.AccountID
INNER JOIN (
    SELECT account_id
    FROM events_account_web_profile
    WHERE partition_date >= today() - 30
    GROUP BY account_id
    HAVING sum(PageViews) > 0
) AS wp ON wp.account_id = so.AccountID
