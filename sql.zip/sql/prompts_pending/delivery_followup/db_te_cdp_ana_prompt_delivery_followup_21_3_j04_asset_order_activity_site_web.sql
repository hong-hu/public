-- Delivered in the last 6 months, still an owner, a rep already followed up, a home charging site on file, and a website visit in the last 30 days
SELECT e.account_id AS AccountID
FROM (
    SELECT account_id
    FROM events_account_web_profile
    PREWHERE partition_date >= today() - 30
      AND PageViews > 0
    GROUP BY account_id
) AS e
LEFT SEMI JOIN (
    SELECT AccountID
    FROM vehicle_asset_entity FINAL
    PREWHERE Status = 'DELIVERED'
      AND DeliveredDate >= today() - 180
) AS v ON e.account_id = v.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    PREWHERE TotalOwnedVehicles > 0
) AS o ON e.account_id = o.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    PREWHERE ActivityStatus = 'Completed'
      AND AccountID != ''
) AS s ON e.account_id = s.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM sites_entity FINAL
    PREWHERE ProjectType IN ('Residential', 'HomeCharging')
) AS t ON e.account_id = t.AccountID
