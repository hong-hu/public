-- A car delivered in the last 4 months, another order still open, a rep appointment on the calendar, and visited inventory in the last 30 days
SELECT DISTINCT p.account_id AS account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM vehicle_asset_entity FINAL
  WHERE Status = 'DELIVERED' AND ISActive = 1 AND DeliveredDate >= today() - INTERVAL 120 DAY) AS v
  ON p.account_id = v.AccountID
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalInprogressOrderd > 0) AS o
  ON p.account_id = o.AccountID
INNER JOIN (SELECT AccountID FROM account_sales_activity_entity FINAL
  WHERE ActivityStatus = 'Scheduled') AS a
  ON p.account_id = a.AccountID
WHERE p.partition_date >= today() - 30
GROUP BY p.account_id
HAVING uniqIfMerge(p.InventoryVisits) > 0
