-- A car delivered in the last 90 days, a completed follow-up with a rep, and a visit to Model 3, Model Y, or Cybertruck support in the last 30 days
SELECT DISTINCT AccountID
FROM account_sales_activity_entity FINAL
PREWHERE AccountID IN (
    SELECT DISTINCT AccountID
    FROM vehicle_asset_entity FINAL
    PREWHERE DeliveredDate >= today() - 90
    WHERE Status = 'DELIVERED'
      AND AccountID IN (
          SELECT account_id
          FROM events_account_web_profile
          WHERE partition_date >= today() - 30
            AND finalizeAggregation(Model3SupportVisits)
              + finalizeAggregation(ModelYSupportVisits)
              + finalizeAggregation(CybertruckSupportVisits) > 0
      )
)
WHERE AccountID != ''
  AND ActivityType = 'Follow-up'
  AND ActivityStatus = 'Completed'
