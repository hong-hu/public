-- Businesses that already have vehicles on the road, another order still open, a charging site underway, and someone on the website in the last 30 days
SELECT DISTINCT p.account_id AS account_id
FROM events_account_web_profile AS p
INNER JOIN (SELECT AccountID FROM account_entity FINAL
  WHERE AccountType = 'BUSINESS') AS ae
  ON p.account_id = ae.AccountID
INNER JOIN (SELECT AccountID FROM account_order_aggregation FINAL
  WHERE TotalOwnedVehicles > 0 AND TotalInprogressOrderd > 0) AS o
  ON p.account_id = o.AccountID
INNER JOIN (SELECT AccountID FROM sites_entity FINAL
  WHERE ProjectType IN ('HomeCharging', 'CommercialCharging', 'Supercharger', 'Supercharger V3')
    AND Status IN ('Site Initiated', 'Preliminary', 'Open', 'Shipped')) AS s
  ON p.account_id = s.AccountID
WHERE p.partition_date >= today() - 30
