-- Corporate and fleet accounts with two or more delivered vehicles that used the enterprise configurator in the last 30 days
SELECT DISTINCT account_id AS AccountID
FROM events_account_web_profile
PREWHERE partition_date >= today() - 30
  AND finalizeAggregation(CfgTypeEnterprise) > 0
  AND account_id IN (
    SELECT AccountID
    FROM account_entity FINAL
    WHERE AccountType = 'BUSINESS'
      AND BusinessAccountType IN ('Corporate', 'Lease & Fleet Management')
      AND AccountID IN (
        SELECT AccountID
        FROM vehicle_asset_entity FINAL
        PREWHERE Status = 'DELIVERED' AND ISActive = 1
        GROUP BY AccountID
        HAVING count() >= 2
      )
  )
