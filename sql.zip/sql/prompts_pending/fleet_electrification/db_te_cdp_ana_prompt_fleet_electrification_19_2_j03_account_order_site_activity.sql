-- Businesses running more than one model, with a charging site already underway and a rep in touch in the last 90 days
SELECT asa.AccountID
FROM (
    SELECT AccountID
    FROM account_sales_activity_entity FINAL
    WHERE EventTime >= today() - 90
        AND AccountID != ''
    GROUP BY AccountID
) AS asa
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_entity FINAL
    PREWHERE AccountType = 'BUSINESS'
) AS ae ON asa.AccountID = ae.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM sites_entity FINAL
    PREWHERE Status IN ('Open', 'Operating', 'Shipped')
    WHERE ProjectType IN ('CommercialCharging', 'CommercialEnergy', 'HomeCharging')
    GROUP BY AccountID
) AS se ON asa.AccountID = se.AccountID
LEFT SEMI JOIN (
    SELECT AccountID
    FROM account_order_aggregation FINAL
    PREWHERE TotalOwnedVehicles > 0
    WHERE length(Models) >= 2
) AS aoa ON asa.AccountID = aoa.AccountID
