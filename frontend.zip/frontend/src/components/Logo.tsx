export function LogoMark({ className = 'w-9 h-9' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="tm-logo-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#34d399" />
          <stop offset="1" stopColor="#059669" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="56" height="56" rx="14" fill="url(#tm-logo-g)" />
      <path
        d="M22 44 C14 40 14 28 21 24 C21 15 33 12 38 18 C47 17 52 26 47 33 C50 40 43 47 36 44 C32 48 25 48 22 44 Z"
        stroke="#022c22"
        strokeWidth="2.5"
        fill="rgba(2,44,34,0.12)"
        strokeLinecap="round"
      />
      <g stroke="#022c22" strokeWidth="1.6" opacity="0.75">
        <line x1="26" y1="28" x2="38" y2="25" />
        <line x1="26" y1="28" x2="33" y2="36" />
        <line x1="38" y1="25" x2="33" y2="36" />
        <line x1="33" y1="36" x2="42" y2="37" />
        <line x1="38" y1="25" x2="42" y2="37" />
      </g>
      <g fill="#022c22">
        <circle cx="26" cy="28" r="2.6" />
        <circle cx="38" cy="25" r="2.6" />
        <circle cx="33" cy="36" r="2.6" />
        <circle cx="42" cy="37" r="2.2" />
      </g>
    </svg>
  )
}

export function Logo() {
  return (
    <a href="#" className="flex items-center gap-2.5 group transition-transform hover:scale-[1.02]">
      <div className="rounded-xl shadow-lg shadow-emerald-500/20">
        <LogoMark />
      </div>
      {/* Icon-only below sm — the wordmark doesn't fit next to three tabs on phones */}
      <span className="hidden sm:block text-2xl tracking-tight text-foreground">
        <span className="font-light">Transparent</span>
        <span className="font-bold text-emerald-400"> Minds</span>
      </span>
    </a>
  )
}
