import { Check } from 'lucide-react'

export type Step = 1 | 2

const chevron = {
  clipPath: 'polygon(0 0, calc(100% - 18px) 0, 100% 50%, calc(100% - 18px) 100%, 0 100%, 18px 50%)',
}

export function Stepper({
  step,
  onStep,
  noun = 'Prompt',
  exploreNoun,
}: {
  step: Step
  onStep: (s: Step) => void
  /** What one row of the dataset is called: "Prompt" (auditing) or "Problem" (coding). */
  noun?: string
  /** What step 2 explores when it differs from the row noun (cot: "Thinking"). */
  exploreNoun?: string
}) {
  const steps: { id: Step; label: string; short: string; hint: string }[] = [
    { id: 1, label: `Select ${noun}`, short: 'Select', hint: `Pick a ${noun.toLowerCase()} from the dataset` },
    { id: 2, label: `Explore ${exploreNoun ?? noun}`, short: 'Explore', hint: 'Peer into each model’s latent mind' },
  ]
  return (
    <div className="flex w-full max-w-3xl mx-auto select-none">
      {steps.map((s, i) => {
        const active = step === s.id
        const complete = step > s.id
        return (
          <button
            key={s.id}
            onClick={() => onStep(s.id)}
            style={chevron}
            className={`relative flex-1 flex items-center justify-center gap-3 py-4 transition-all duration-300 cursor-pointer ${
              i > 0 ? '-ml-3' : ''
            } ${
              active
                ? 'bg-emerald-500 text-emerald-950 shadow-lg shadow-emerald-500/20'
                : complete
                  ? 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25'
                  : 'bg-secondary/50 text-muted-foreground hover:bg-secondary hover:text-foreground'
            }`}
          >
            <span
              className={`flex items-center justify-center w-6 h-6 rounded-full text-[11px] font-bold border ${
                active
                  ? 'border-emerald-900/40 bg-emerald-950/10'
                  : complete
                    ? 'border-emerald-500/40 bg-emerald-500/10'
                    : 'border-border bg-background/40'
              }`}
            >
              {complete ? <Check className="w-3.5 h-3.5" /> : s.id}
            </span>
            <span className="text-left">
              {/* Mobile: the noun is dropped so both chevrons fit a phone */}
              <span className="block sm:hidden text-xs font-bold uppercase tracking-[0.15em]">{s.short}</span>
              <span className="hidden sm:block text-xs font-bold uppercase tracking-[0.15em]">{s.label}</span>
              <span className={`hidden sm:block text-[10px] ${active ? 'text-emerald-900/80' : 'text-muted-foreground/70'}`}>
                {s.hint}
              </span>
            </span>
          </button>
        )
      })}
    </div>
  )
}
