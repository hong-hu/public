import { useEffect, useState } from 'react'
import { Moon, Sun } from 'lucide-react'
import { Logo } from './Logo'
import type { DatasetInfo } from '../lib/types'

export type Tab = string

export function Navigation({
  active,
  onChange,
  datasets = [],
}: {
  active: Tab
  onChange: (t: Tab) => void
  datasets?: DatasetInfo[]
}) {
  const [scrolled, setScrolled] = useState(false)
  const [theme, setTheme] = useState<'dark' | 'light'>(() =>
    localStorage.getItem('tm-theme') === 'light' ? 'light' : 'dark',
  )

  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light')
    localStorage.setItem('tm-theme', theme)
  }, [theme])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const allTabs = datasets.map((d) => ({ key: d.key, label: d.label }))

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-background/60 backdrop-blur-xl border-b border-white/5 light:border-black/10 py-3' : 'bg-transparent py-5'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-6 lg:px-8 flex items-center justify-between">
        <Logo />
        {/* Slogan — centered in the space between logo and tabs; truncates
            instead of running into the tab row, hidden when space is tight */}
        <span className="hidden lg:block flex-1 min-w-0 px-8 text-center text-sm font-medium text-muted-foreground tracking-wide pointer-events-none select-none truncate">
          See What Models <span className="text-emerald-400 font-semibold">Think</span>, Not Just What They Say
        </span>
        <div className="flex items-center gap-5 sm:gap-8 lg:gap-10">
          {allTabs.map((t) => {
            const isActive = active === t.key
            return (
              <button
                key={t.key}
                onClick={() => onChange(t.key)}
                className={`font-bold uppercase tracking-[0.2em] transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'text-xs text-foreground underline underline-offset-8 decoration-emerald-500/60'
                    : 'text-[10px] text-muted-foreground hover:text-emerald-400'
                }`}
              >
                {t.label}
              </button>
            )
          })}
          <button
            onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="text-muted-foreground hover:text-emerald-400 transition-colors cursor-pointer"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </nav>
    </header>
  )
}
