import { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Stepper, type Step } from './Stepper'
import { SelectPrompt, type TypeFilter } from './SelectPrompt'
import { ExplorePrompt } from './ExplorePrompt'
import { loadPrompts } from '../lib/data'
import type { DatasetKind, PromptRow } from '../lib/types'

export function DatasetTab({
  datasetKey = 'auditing',
  kind = 'auditing',
  cot = false,
}: {
  datasetKey?: string
  kind?: DatasetKind
  cot?: boolean
}) {
  const [prompts, setPrompts] = useState<PromptRow[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [step, setStep] = useState<Step>(1)
  const [selectedId, setSelectedId] = useState<string | null>(null)

  // Filter state lives here so it survives switching between steps.
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all')
  const [categories, setCategories] = useState<Set<string> | 'all'>('all')
  const [search, setSearch] = useState('')

  useEffect(() => {
    setPrompts(null)
    setError(null)
    loadPrompts(datasetKey)
      .then((p) => {
        setPrompts(p)
        setSelectedId((cur) => cur ?? p[0]?.id ?? null)
      })
      .catch((e) => setError(String(e)))
  }, [datasetKey])

  const selected = useMemo(
    () => prompts?.find((p) => p.id === selectedId) ?? null,
    [prompts, selectedId],
  )

  if (error) {
    return <div className="text-center text-destructive py-20">{error}</div>
  }
  if (!prompts) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping mr-3" />
        Loading dataset…
      </div>
    )
  }

  return (
    <section>
      <Stepper
        step={step}
        onStep={setStep}
        noun={kind === 'coding' ? 'Problem' : 'Prompt'}
        exploreNoun={cot ? 'Thinking' : undefined}
      />
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10"
        >
          {step === 1 ? (
            <SelectPrompt
              prompts={prompts}
              selectedId={selectedId}
              onSelect={setSelectedId}
              typeFilter={typeFilter}
              onTypeFilter={setTypeFilter}
              categories={categories}
              onCategories={setCategories}
              search={search}
              onSearch={setSearch}
              onExplore={() => setStep(2)}
              datasetKey={datasetKey}
              kind={kind}
              cot={cot}
            />
          ) : selected ? (
            <ExplorePrompt prompt={selected} datasetKey={datasetKey} kind={kind} cot={cot} />
          ) : null}
        </motion.div>
      </AnimatePresence>
    </section>
  )
}
