import { useMemo } from 'react'
import { CODE_COLORS, parseCodeLines } from '../lib/code'
import { parseProblem } from '../lib/leetcode'
import { splitWords } from '../lib/positions'

/** LeetCode-style rendering of a coding prompt (parsed by lib/leetcode.ts). */

function SectionHeading({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-2 font-bold text-[13px] text-foreground">
      <span className="w-1 h-3.5 rounded-full bg-emerald-500" />
      {text}
    </div>
  )
}

export function ProblemStatement({ text }: { text: string }) {
  const blocks = useMemo(() => parseProblem(text), [text])

  return (
    <div className="space-y-4">
      {blocks.map((b, bi) => {
        switch (b.type) {
          // Prompt scaffolding (preamble + Requirements) is not part of the
          // problem definition — don't show it.
          case 'muted':
          case 'requirements':
            return null
          case 'example':
            return (
              <div key={bi} className="space-y-2">
                <SectionHeading text={`${b.title}:`} />
                <div className="rounded-lg border border-border bg-black/25 light:bg-black/[0.04] px-4 py-3 font-mono [font-variant-ligatures:none] text-[12.5px] leading-relaxed space-y-1">
                  {b.rows.map((r, ri) => (
                    <div key={ri} className="whitespace-pre-wrap break-words">
                      {r.label && <span className="font-bold text-emerald-300/90">{r.label}: </span>}
                      <span className="text-foreground/80">{r.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            )
          case 'constraints':
            return (
              <div key={bi} className="space-y-2">
                <SectionHeading text="Constraints:" />
                <ul className="space-y-1.5 pl-1.5">
                  {b.items.map((item, ii) => (
                    <li key={ii} className="flex items-baseline gap-2.5">
                      <span className="w-1 h-1 rounded-full bg-emerald-400/80 shrink-0" />
                      <code className="font-mono [font-variant-ligatures:none] text-[12.5px] text-foreground/85">{item}</code>
                    </li>
                  ))}
                </ul>
              </div>
            )
          case 'followup':
            return (
              <p key={bi} className="text-sm leading-relaxed text-foreground/90">
                <span className="font-bold text-foreground">Follow-up: </span>
                {b.text}
              </p>
            )
          case 'code': {
            const codeLines = parseCodeLines(b.code, splitWords(b.code))
            return (
              <div key={bi} className="space-y-2">
                <SectionHeading text="Starter code:" />
                <pre className="rounded-lg border border-white/10 light:border-black/10 bg-black/40 light:bg-black/[0.04] p-4 font-mono [font-variant-ligatures:none] text-[12.5px] leading-relaxed overflow-x-auto">
                  {codeLines.map((l, li) => (
                    <div key={li}>
                      {l.words.map((w) => (
                        <span key={w.index} className={w.cls ? CODE_COLORS[w.cls] : undefined}>
                          {w.pre}
                          {w.text}
                        </span>
                      ))}
                      {l.words.length === 0 && ' '}
                    </div>
                  ))}
                </pre>
              </div>
            )
          }
          default:
            return (
              <p key={bi} className="text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap">
                {b.text}
              </p>
            )
        }
      })}
    </div>
  )
}
