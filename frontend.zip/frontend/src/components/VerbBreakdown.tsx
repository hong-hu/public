import type { ComponentType } from 'react'
import { ChevronsRight, Layers, Quote, Target } from 'lucide-react'
import type { VerbSections } from '../lib/types'

/**
 * Activation verbalizations can come as pre-parsed objects with format, phrase,
 * intent, and expectation, or as raw strings that need to be parsed.
 */
function parseVerb(verb: string): VerbSections | null {
  const paras = verb
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean)
  if (paras.length < 2) return null

  const s: VerbSections = { format: null, phrase: null, intent: null, expectation: null, extra: [] }
  for (const p of paras) {
    if (!s.expectation && /^final (token|sentence|word|phrase)/i.test(p)) s.expectation = p
    else if (!s.phrase && /^the (phrase|sentence|paragraph|closing|word)/i.test(p)) s.phrase = p
    else if (!s.format) s.format = p
    else s.extra!.push(p)
  }
  if (!s.format || (!s.phrase && !s.expectation)) return null
  return s
}

/** Emphasize quoted snippets — the phrases and candidate continuations. */
function QuotedText({ text }: { text: string }) {
  const parts = text.split(/("[^"]*"|“[^”]*”)/g)
  return (
    <>
      {parts.map((part, i) =>
        /^["“]/.test(part) ? (
          <span key={i} className="text-emerald-300/90 font-medium">
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </>
  )
}

function Section({
  icon: Icon,
  label,
  text,
  emphasized = false,
}: {
  icon: ComponentType<{ className?: string }>
  label: string
  text?: string | null
  emphasized?: boolean
}) {
  if (!text) return null
  return (
    <div className="space-y-1">
      <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-emerald-500/70">
        <Icon className="w-3 h-3" />
        <span>{label}</span>
      </div>
      <p
        className={
          emphasized
            ? 'text-sm leading-relaxed text-foreground font-medium whitespace-pre-line'
            : 'text-xs leading-relaxed text-foreground/80 whitespace-pre-line'
        }
      >
        <QuotedText text={text} />
      </p>
    </div>
  )
}

export function getVerbPhrase(verb?: VerbSections | string | null): string | null {
  if (!verb) return null
  if (typeof verb === 'string') {
    const sections = parseVerb(verb)
    return sections?.phrase || verb
  }
  return verb.phrase || null
}

export function VerbPhrase({ verb }: { verb?: VerbSections | string | null }) {
  const phrase = getVerbPhrase(verb)
  if (!phrase) return null
  return (
    <p className="text-xs leading-relaxed text-foreground/80 whitespace-pre-line">
      <QuotedText text={phrase} />
    </p>
  )
}

export function VerbBreakdown({ verb }: { verb?: VerbSections | string | null }) {
  if (!verb) return null
  const sections: VerbSections | null = typeof verb === 'string' ? parseVerb(verb) : verb
  if (!sections) {
    return (
      <p className="text-xs leading-relaxed text-foreground/80 whitespace-pre-line">
        <QuotedText text={typeof verb === 'string' ? verb : ''} />
      </p>
    )
  }
  return (
    <div className="space-y-3">
      {sections.format && <Section icon={Layers} label="Format Signal" text={sections.format} />}
      {sections.phrase && <Section icon={Quote} label="Key Phrase" text={sections.phrase} emphasized />}
      {sections.intent && <Section icon={Target} label="Intent" text={sections.intent} />}
      {sections.expectation && (
        <Section icon={ChevronsRight} label="Next-Token Expectation" text={sections.expectation} />
      )}
      {sections.extra?.map((p, i) => (
        <p key={i} className="text-xs leading-relaxed text-foreground/80 whitespace-pre-line">
          <QuotedText text={p} />
        </p>
      ))}
    </div>
  )
}
