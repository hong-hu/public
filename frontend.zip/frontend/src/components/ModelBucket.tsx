import { useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { motion } from 'framer-motion'
import { Brain, RotateCcw, Sparkles } from 'lucide-react'
import { loadModelBundle } from '../lib/data'
import { CODE_COLORS, parseCodeLines } from '../lib/code'
import { parseMarkdownBlocks, type MdWord } from '../lib/markdown'
import { lineEndWordIndices, mapPositionsToWords, splitWords } from '../lib/positions'
import { useIsMobile } from '../lib/useIsMobile'
import type { DatasetKind, ModelInfo, PromptRow, PromptTrace } from '../lib/types'
import { VerbBreakdown } from './VerbBreakdown'
import { ThinkingProcess } from './ThinkingProcess'

const sectionLabel =
  'flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60'

export function ModelBucket({
  model,
  prompt,
  datasetKey = 'auditing',
  kind = 'auditing',
  cot = false,
}: {
  model: ModelInfo
  prompt: PromptRow
  datasetKey?: string
  kind?: DatasetKind
  cot?: boolean
}) {
  const isMobile = useIsMobile()
  const [trace, setTrace] = useState<PromptTrace | null | undefined>(undefined)
  const [revealCount, setRevealCount] = useState(0)
  const [hoveredPos, setHoveredPos] = useState<number | null>(null)
  const [runId, setRunId] = useState(0)
  const markerRefs = useRef(new Map<number, HTMLElement>())

  useEffect(() => {
    let cancelled = false
    setTrace(undefined)
    loadModelBundle(datasetKey, model.key).then((bundle) => {
      if (!cancelled) setTrace(bundle[prompt.id] ?? null)
    })
    return () => {
      cancelled = true
    }
  }, [datasetKey, model.key, prompt.id])

  // cot traces: the activation positions describe the thinking, so the answer
  // gets no markers at all and the thinking view hosts them instead.
  const isCot = cot && trace?.thinking != null

  const words = useMemo(() => (trace ? splitWords(trace.answer) : []), [trace])
  const blocks = useMemo(
    () => (trace && kind !== 'coding' ? parseMarkdownBlocks(trace.answer, words) : []),
    [trace, words, kind],
  )
  const posToWord = useMemo(
    () =>
      trace && !isCot
        ? mapPositionsToWords(
            trace.positions.map((p) => p.pos),
            words,
            // Code positions land on line endings, not sentence endings.
            kind === 'coding' ? lineEndWordIndices(trace.answer, words) : undefined,
          )
        : new Map<number, number>(),
    [trace, words, kind, isCot],
  )

  // cot: one thinking sentence per line. Position 1 marks the point right
  // after the prompt (a synthetic empty line above), position k >= 2 marks the
  // end of thinking line k-1; any extra positions clamp to the last line.
  const thinkLines = useMemo(
    () => (isCot && trace?.thinking ? trace.thinking.split('\n').filter((l) => l.trim()) : []),
    [trace, isCot],
  )
  const thinkLineWords = useMemo(
    () => thinkLines.map((l) => l.split(/\s+/).filter(Boolean)),
    [thinkLines],
  )
  const thinkLineStart = useMemo(() => {
    const out: number[] = []
    let acc = 0
    for (const ws of thinkLineWords) {
      out.push(acc)
      acc += ws.length
    }
    return out
  }, [thinkLineWords])
  const thinkTotal = thinkLineWords.reduce((n, ws) => n + ws.length, 0)
  const cotFirstPos = isCot && trace && trace.positions.length > 0 ? trace.positions[0].pos : null
  const cotLineMarks = useMemo(() => {
    const m = new Map<number, number[]>()
    if (!isCot || !trace || thinkLines.length === 0) return m
    trace.positions.slice(1).forEach((p, i) => {
      const li = Math.min(i, thinkLines.length - 1)
      m.set(li, [...(m.get(li) ?? []), p.pos])
    })
    return m
  }, [trace, thinkLines, isCot])

  // Coding: the answer is Python source, rendered line by line with a gutter.
  const codeLines = useMemo(
    () => (trace && kind === 'coding' ? parseCodeLines(trace.answer, words) : []),
    [trace, words, kind],
  )
  // The answer-start position (word 0) gets its own synthetic empty line above
  // the code, so it never shares line 1 with the next position (which usually
  // snaps to line 1's end).
  const firstPos = useMemo(() => {
    if (kind !== 'coding') return null
    for (const [pos, wIdx] of posToWord) if (wIdx === 0) return pos
    return null
  }, [posToWord, kind])

  // Line index -> activation positions for the full-line marks + gutter nodes.
  const lineMarks = useMemo(() => {
    const m = new Map<number, number[]>()
    if (kind !== 'coding') return m
    const wordToLine = new Map<number, number>()
    codeLines.forEach((l, li) => l.words.forEach((w) => wordToLine.set(w.index, li)))
    for (const [pos, wIdx] of posToWord) {
      if (pos === firstPos) continue // hosted by the synthetic top line
      const li = wordToLine.get(wIdx)
      if (li !== undefined) m.set(li, [...(m.get(li) ?? []), pos])
    }
    for (const arr of m.values()) arr.sort((a, b) => a - b)
    return m
  }, [codeLines, posToWord, kind, firstPos])
  // Streaming visibility for blank lines: the first word index at or after the line.
  const lineStartIdx = useMemo(() => {
    const out: number[] = new Array(codeLines.length).fill(Infinity)
    let next = Infinity
    for (let i = codeLines.length - 1; i >= 0; i--) {
      if (codeLines[i].words.length > 0) next = codeLines[i].words[0].index
      out[i] = next
    }
    return out
  }, [codeLines])
  const wordToPos = useMemo(() => {
    const m = new Map<number, number>()
    for (const [pos, idx] of posToWord) m.set(idx, pos)
    return m
  }, [posToWord])
  const entryByPos = useMemo(
    () => new Map((trace?.positions ?? []).map((p) => [p.pos, p])),
    [trace],
  )

  // Stream word by word (~6s for long answers); cot streams the thinking
  // first, then the answer, on the same counter.
  const totalWords = thinkTotal + words.length
  useEffect(() => {
    if (!trace) return
    setRevealCount(0)
    const step = Math.max(1, Math.ceil(totalWords / 380))
    const interval = setInterval(() => {
      setRevealCount((c) => {
        if (c >= totalWords) {
          clearInterval(interval)
          return c
        }
        return Math.min(c + step, totalWords)
      })
    }, 16)
    return () => clearInterval(interval)
  }, [trace, totalWords, runId])

  const streaming = trace != null && revealCount < totalWords
  // How many answer words are revealed — everything after the thinking phase.
  const answerReveal = Math.max(0, revealCount - thinkTotal)

  // Keep the scanline mounted briefly after streaming ends so its transition
  // visibly reaches the bottom of the box before it disappears.
  const [showScanline, setShowScanline] = useState(false)
  useEffect(() => {
    if (streaming) {
      setShowScanline(true)
      return
    }
    const t = setTimeout(() => setShowScanline(false), 400)
    return () => clearTimeout(t)
  }, [streaming])
  const hoverFromTable = (pos: number | null) => {
    setHoveredPos(pos)
    if (pos !== null) {
      markerRefs.current.get(pos)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    }
  }

  // Desktop: the activation popover follows the mouse (enter/leave). Mobile has
  // no hover, so markers become tap-to-toggle and tapping anywhere else closes.
  const interact = (pos: number) =>
    isMobile
      ? {
          onClick: (e: React.MouseEvent) => {
            e.stopPropagation()
            setHoveredPos((p) => (p === pos ? null : pos))
          },
        }
      : { onMouseEnter: () => setHoveredPos(pos), onMouseLeave: () => setHoveredPos(null) }

  useEffect(() => {
    if (!isMobile || hoveredPos === null) return
    const close = () => setHoveredPos(null)
    document.addEventListener('click', close)
    return () => document.removeEventListener('click', close)
  }, [isMobile, hoveredPos])

  // Track the hovered word's viewport rect each frame (it moves while the
  // answer auto-scrolls) so the portal popover stays glued to it.
  const [anchorRect, setAnchorRect] = useState<DOMRect | null>(null)
  useEffect(() => {
    if (hoveredPos === null) {
      setAnchorRect(null)
      return
    }
    let raf = 0
    const tick = () => {
      const el = markerRefs.current.get(hoveredPos)
      const r = el?.getBoundingClientRect() ?? null
      setAnchorRect((prev) => {
        if (!r) return null
        if (prev && Math.abs(prev.top - r.top) < 0.5 && Math.abs(prev.left - r.left) < 0.5) return prev
        return r
      })
      raf = requestAnimationFrame(tick)
    }
    tick()
    return () => cancelAnimationFrame(raf)
  }, [hoveredPos])

  // One answer word: activation-marked words keep the highlight + hover
  // popover (unchanged); plain words pick up their inline markdown styling.
  const renderWord = (mw: MdWord) => {
    const pos = wordToPos.get(mw.index)
    if (pos === undefined) {
      if (mw.hidden) return null
      const cls = [
        mw.bold ? 'font-bold text-foreground' : '',
        mw.italic ? 'italic' : '',
        mw.code ? 'font-mono [font-variant-ligatures:none] text-[13px] text-emerald-200/90 bg-white/[0.07] light:bg-black/[0.05] px-1 py-0.5 rounded' : '',
      ]
        .filter(Boolean)
        .join(' ')
      return (
        <span key={mw.index} className={cls || undefined}>
          {mw.text}{' '}
        </span>
      )
    }
    const hovered = hoveredPos === pos
    return (
      <motion.span
        key={mw.index}
        ref={(el) => {
          if (el) markerRefs.current.set(pos, el)
        }}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        {...interact(pos)}
        className={`relative inline-block cursor-help font-sans not-italic mx-[1px] px-1 rounded border-b-2 transition-all duration-200 ${
          hovered
            ? 'bg-emerald-500/40 text-emerald-100 border-emerald-300 scale-110 z-10 shadow-[0_0_16px_rgba(16,185,129,0.6)]'
            : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 hover:bg-emerald-500/30'
        }`}
      >
        {mw.hidden ? words[mw.index].text : mw.text}{' '}
      </motion.span>
    )
  }

  if (trace === undefined) {
    return (
      <div className="rounded-2xl border border-border bg-card/40 p-10 flex items-center justify-center text-muted-foreground">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping mr-3" />
        Loading {model.label} trace…
      </div>
    )
  }
  if (trace === null) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
        No trace recorded for prompt #{prompt.id} on {model.label}.
      </div>
    )
  }

  return (
    <div className="@container rounded-2xl border border-border bg-background shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border flex flex-wrap items-center justify-between gap-3 bg-black/10 light:bg-black/[0.03]">
        <div className="flex items-center gap-3">
          {trace.verdict ? (
            <div className="relative group inline-flex items-center">
              <span
                className={`inline-block w-3.5 h-3.5 rounded-full cursor-help transition-all duration-200 group-hover:scale-125 ${
                  trace.verdict.is_invalid
                    ? 'bg-red-500 shadow-lg shadow-red-500/60 ring-4 ring-red-500/20'
                    : 'bg-emerald-500 shadow-lg shadow-emerald-500/60 ring-4 ring-emerald-500/20'
                }`}
              />
              <div className="absolute left-0 top-full mt-3 hidden group-hover:block z-[100] w-80 p-3.5 text-xs leading-relaxed text-foreground bg-card border border-border rounded-xl shadow-2xl pointer-events-none break-words whitespace-normal">
                <div className="font-bold uppercase tracking-wider text-[10px] mb-1.5 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${trace.verdict.is_invalid ? 'bg-red-500' : 'bg-emerald-500'}`} />
                  {trace.verdict.total_cases != null
                    ? trace.verdict.is_invalid
                      ? 'Test Cases Failed'
                      : 'All Test Cases Passed'
                    : trace.verdict.is_invalid
                      ? 'Invalid Answer Verdict'
                      : 'Valid Answer Verdict'}
                </div>
                <div className="text-muted-foreground font-medium">
                  {trace.verdict.total_cases != null ? (
                    <>
                      Passed{' '}
                      <span className={trace.verdict.is_invalid ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                        {trace.verdict.passed_cases ?? '—'} / {trace.verdict.total_cases}
                      </span>{' '}
                      test cases.
                    </>
                  ) : (
                    trace.verdict.reason ||
                    (trace.verdict.is_invalid
                      ? 'Answer marked as invalid by evaluation judge.'
                      : 'Answer marked as compliant and valid by evaluation judge.')
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div
              className={`w-3 h-3 rounded-full ${
                streaming ? 'bg-emerald-500 animate-pulse' : 'bg-emerald-500 shadow-lg shadow-emerald-500/50'
              }`}
            />
          )}
          <span className="font-semibold text-foreground">{model.label}</span>
          {streaming && <span className="text-[10px] text-emerald-400 animate-pulse font-mono">_streaming</span>}
        </div>
      </div>

      <div className="p-6 lg:p-8 space-y-8">
        {/* Observed Thinking (cot) — streams before the answer. A synthetic
            empty top line hosts the post-prompt activation (node 1); each
            thinking line hosts the activation marked at its end (nodes 2…). */}
        {isCot && trace && (
          <>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className={sectionLabel}>
                  <Brain className="w-3 h-3" />
                  <span>{streaming && revealCount < thinkTotal ? 'Streaming Thinking…' : 'Observed Thinking'}</span>
                </div>
                <button
                  onClick={() => setRunId((r) => r + 1)}
                  className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Replay
                </button>
              </div>
              <div className="relative overflow-hidden rounded-xl">
                {showScanline && revealCount < thinkTotal && (
                  <div
                    style={{ top: `${(revealCount / Math.max(1, thinkTotal)) * 100}%` }}
                    className="absolute left-0 right-0 h-px bg-emerald-400/40 z-20 pointer-events-none shadow-[0_0_15px_rgba(16,185,129,0.8)] transition-[top] duration-150 ease-linear"
                  />
                )}
                <div className="py-4 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.03] text-[14px] leading-[1.9] font-serif text-foreground/90 max-h-[420px] overflow-y-auto scrollbar-thin">
                  {/* Synthetic empty top line hosting the post-prompt activation */}
                  {cotFirstPos !== null && revealCount > 0 && (
                    <div
                      {...interact(cotFirstPos)}
                      className={`flex items-start px-3 transition-colors duration-200 cursor-help ${
                        hoveredPos === cotFirstPos ? 'bg-emerald-500/25' : 'bg-emerald-500/[0.09] hover:bg-emerald-500/[0.16]'
                      }`}
                    >
                      <span className="w-9 shrink-0 select-none flex justify-end items-center pr-2.5 pt-[5px]">
                        <span
                          ref={(el) => {
                            if (el) markerRefs.current.set(cotFirstPos, el)
                          }}
                          className={`inline-flex items-center justify-center w-[18px] h-[18px] rounded-full border font-mono text-[9px] font-bold transition-colors duration-200 ${
                            hoveredPos === cotFirstPos
                              ? 'bg-emerald-500 text-emerald-950 border-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                              : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40'
                          }`}
                        >
                          {trace.positions.findIndex((p) => p.pos === cotFirstPos) + 1}
                        </span>
                      </span>
                      <span className="flex-1 min-w-0">{' '}</span>
                    </div>
                  )}
                  {thinkLines.map((_line, li) => {
                    if (revealCount <= thinkLineStart[li]) return null
                    const ws = thinkLineWords[li]
                    const visN = Math.min(ws.length, revealCount - thinkLineStart[li])
                    const marks = cotLineMarks.get(li) ?? []
                    const marked = marks.length > 0
                    const hovered = hoveredPos !== null && marks.includes(hoveredPos)
                    return (
                      <div
                        key={li}
                        {...(marked ? interact(marks[0]) : {})}
                        className={`flex items-start px-3 transition-colors duration-200 ${
                          marked
                            ? hovered
                              ? 'bg-emerald-500/25 cursor-help'
                              : 'bg-emerald-500/[0.09] cursor-help hover:bg-emerald-500/[0.16]'
                            : ''
                        }`}
                      >
                        {/* Gutter: numbered activation node(s) for the line's end */}
                        <span className="w-9 shrink-0 select-none flex justify-end items-center gap-0.5 pr-2.5 pt-[5px]">
                          {marks.map((pos) => {
                            const markIndex = trace.positions.findIndex((p) => p.pos === pos)
                            const nodeHovered = hoveredPos === pos
                            return (
                              <span
                                key={pos}
                                ref={(el) => {
                                  if (el) markerRefs.current.set(pos, el)
                                }}
                                {...(isMobile ? {} : { onMouseEnter: () => setHoveredPos(pos) })}
                                className={`inline-flex items-center justify-center rounded-full border font-mono font-bold transition-colors duration-200 ${
                                  marks.length > 1 ? 'w-4 h-4 text-[8px]' : 'w-[18px] h-[18px] text-[9px]'
                                } ${
                                  nodeHovered
                                    ? 'bg-emerald-500 text-emerald-950 border-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                                    : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40'
                                }`}
                              >
                                {markIndex + 1}
                              </span>
                            )
                          })}
                        </span>
                        <span className="whitespace-pre-wrap break-words flex-1 min-w-0">
                          {ws.slice(0, visN).join(' ')}
                          {streaming && revealCount < thinkTotal && thinkLineStart[li] + visN === revealCount && (
                            <span className="inline-block w-1.5 h-3.5 bg-emerald-500 ml-0.5 animate-pulse align-middle" />
                          )}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>

            {/* Splitter between thinking and generation */}
            <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
          </>
        )}

        {/* Answer / Observed Generation + activation marker rail */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className={sectionLabel}>
              <Sparkles className="w-3 h-3" />
              <span>{streaming && (!isCot || answerReveal > 0) ? 'Streaming Response…' : 'Observed Generation'}</span>
            </div>
            {!isCot && (
              <button
                onClick={() => setRunId((r) => r + 1)}
                className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-emerald-400 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Replay
              </button>
            )}
          </div>
          <div className="flex gap-3 items-stretch">
            <div className="relative flex-1 overflow-hidden rounded-xl">
              {/* Scanline: a single top-to-bottom pass tracking generation
                  progress, reaching the bottom exactly when streaming ends. */}
              {showScanline && (!isCot || answerReveal > 0) && (
                <div
                  style={{ top: `${(answerReveal / Math.max(1, words.length)) * 100}%` }}
                  className="absolute left-0 right-0 h-px bg-emerald-400/40 z-20 pointer-events-none shadow-[0_0_15px_rgba(16,185,129,0.8)] transition-[top] duration-150 ease-linear"
                />
              )}
              {kind === 'coding' ? (
                <div className="py-4 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.03] font-mono [font-variant-ligatures:none] text-[13px] leading-[1.75] text-foreground/85 max-h-[420px] overflow-y-auto scrollbar-thin">
                  {/* Synthetic empty top line hosting the answer-start activation */}
                  {firstPos !== null && answerReveal > 0 && (
                    <div
                      {...interact(firstPos)}
                      className={`flex items-start px-3 transition-colors duration-200 cursor-help ${
                        hoveredPos === firstPos ? 'bg-emerald-500/25' : 'bg-emerald-500/[0.09] hover:bg-emerald-500/[0.16]'
                      }`}
                    >
                      <span className="w-9 shrink-0 select-none flex justify-end items-center pr-2.5 pt-[3px]">
                        <span
                          ref={(el) => {
                            if (el) markerRefs.current.set(firstPos, el)
                          }}
                          className={`inline-flex items-center justify-center w-[18px] h-[18px] rounded-full border font-mono text-[9px] font-bold transition-colors duration-200 ${
                            hoveredPos === firstPos
                              ? 'bg-emerald-500 text-emerald-950 border-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                              : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40'
                          }`}
                        >
                          {trace.positions.findIndex((p) => p.pos === firstPos) + 1}
                        </span>
                      </span>
                      <span className="flex-1 min-w-0">{' '}</span>
                    </div>
                  )}
                  {codeLines.map((line, li) => {
                    if (lineStartIdx[li] >= answerReveal) return null
                    const vis = line.words.filter((w) => w.index < answerReveal)
                    const marks = lineMarks.get(li) ?? []
                    const marked = marks.length > 0
                    const hovered = hoveredPos !== null && marks.includes(hoveredPos)
                    return (
                      <div
                        key={li}
                        {...(marked ? interact(marks[0]) : {})}
                        className={`flex items-start px-3 transition-colors duration-200 ${
                          marked
                            ? hovered
                              ? 'bg-emerald-500/25 cursor-help'
                              : 'bg-emerald-500/[0.09] cursor-help hover:bg-emerald-500/[0.16]'
                            : ''
                        }`}
                      >
                        {/* Gutter: numbered activation node(s) on marked lines, line number otherwise */}
                        <span className="w-9 shrink-0 select-none flex justify-end items-center gap-0.5 pr-2.5 pt-[3px]">
                          {marked ? (
                            marks.map((pos) => {
                              const markIndex = trace.positions.findIndex((p) => p.pos === pos)
                              const nodeHovered = hoveredPos === pos
                              return (
                                <span
                                  key={pos}
                                  ref={(el) => {
                                    if (el) markerRefs.current.set(pos, el)
                                  }}
                                  {...(isMobile ? {} : { onMouseEnter: () => setHoveredPos(pos) })}
                                  className={`inline-flex items-center justify-center rounded-full border font-mono font-bold transition-colors duration-200 ${
                                    marks.length > 1 ? 'w-4 h-4 text-[8px]' : 'w-[18px] h-[18px] text-[9px]'
                                  } ${
                                    nodeHovered
                                      ? 'bg-emerald-500 text-emerald-950 border-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                                      : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40'
                                  }`}
                                >
                                  {markIndex + 1}
                                </span>
                              )
                            })
                          ) : (
                            <span className="text-[10px] leading-[1.75] text-muted-foreground/40">{line.no}</span>
                          )}
                        </span>
                        <span className="whitespace-pre-wrap break-words flex-1 min-w-0">
                          {vis.map((w) => (
                            <span key={w.index} className={w.cls ? CODE_COLORS[w.cls] : undefined}>
                              {w.pre}
                              {w.text}
                            </span>
                          ))}
                          {streaming && vis.length > 0 && vis[vis.length - 1].index === answerReveal - 1 && (
                            <span className="inline-block w-1.5 h-3.5 bg-emerald-500 ml-0.5 animate-pulse align-middle" />
                          )}
                          {vis.length === 0 && ' '}
                        </span>
                      </div>
                    )
                  })}
                </div>
              ) : (
              <div className="p-6 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.03] leading-[1.9] text-[15px] font-serif text-foreground/90 max-h-[420px] overflow-y-auto scrollbar-thin">
              {blocks.map((b, bi) => {
                // Streaming: a block appears once its first word is revealed,
                // then fills word by word like before.
                const vis = b.words.filter((mw) => mw.index < answerReveal)
                if (vis.length === 0) return null
                switch (b.type) {
                  case 'h1':
                  case 'h2':
                  case 'h3':
                    return (
                      <div
                        key={bi}
                        className={`font-sans font-bold text-foreground mt-4 mb-2 first:mt-0 ${
                          b.type === 'h1' ? 'text-xl' : b.type === 'h2' ? 'text-lg' : 'text-base'
                        }`}
                      >
                        {vis.map(renderWord)}
                      </div>
                    )
                  case 'li':
                    return (
                      <div key={bi} className="flex gap-2 pl-1 my-0.5">
                        <span className="text-emerald-400/80 shrink-0 select-none font-sans">{b.marker}</span>
                        <span>{vis.map(renderWord)}</span>
                      </div>
                    )
                  case 'code':
                    return (
                      <pre
                        key={bi}
                        className="my-3 p-3 rounded-lg bg-black/40 light:bg-black/[0.04] border border-white/10 light:border-black/10 font-mono [font-variant-ligatures:none] text-[13px] leading-relaxed whitespace-pre-wrap overflow-x-auto"
                      >
                        {vis.map((mw, i) => (
                          <span key={mw.index}>
                            {mw.newline && i > 0 ? '\n' : ''}
                            {renderWord(mw)}
                          </span>
                        ))}
                      </pre>
                    )
                  case 'hr':
                    return <div key={bi} className="h-px bg-border my-3" />
                  default:
                    return (
                      <p key={bi} className="my-2.5 first:mt-0 last:mb-0">
                        {vis.map(renderWord)}
                      </p>
                    )
                }
              })}
                {streaming && (!isCot || answerReveal > 0) && (
                  <span className="inline-block w-1.5 h-4 bg-emerald-500 ml-1 animate-pulse align-middle" />
                )}
              </div>
              )}
            </div>

            {/* Narrow rail: one numbered marker per activation position, top-down.
                Same node styling as the Thinking Process node column. For coding
                and cot the gutter nodes inside the code/thinking view replace it. */}
            {kind !== 'coding' && !isCot && (
            <div className="flex flex-col items-center justify-center py-1 w-9 shrink-0">
              {trace.positions.map((p, i) => {
                const hovered = hoveredPos === p.pos
                return (
                  <div key={p.pos} className="flex flex-col items-center">
                    {i > 0 && (
                      <div className="w-px h-4 bg-gradient-to-b from-emerald-400/70 to-emerald-500/25" />
                    )}
                    <button
                      {...(isMobile
                        ? {
                            onClick: (e: React.MouseEvent) => {
                              e.stopPropagation()
                              hoverFromTable(hoveredPos === p.pos ? null : p.pos)
                            },
                          }
                        : { onMouseEnter: () => hoverFromTable(p.pos), onMouseLeave: () => hoverFromTable(null) })}
                      aria-label={`activation_${p.pos}`}
                      className={`w-7 h-7 rounded-full border font-mono text-[11px] font-bold flex items-center justify-center transition-all duration-200 cursor-pointer ${
                        hovered
                          ? 'bg-emerald-500 text-emerald-950 border-emerald-300 scale-110 shadow-[0_0_14px_rgba(16,185,129,0.7)]'
                          : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/20'
                      }`}
                    >
                      {i + 1}
                    </button>
                  </div>
                )
              })}
            </div>
            )}
          </div>
        </div>

        {/* Splitter between the two sections */}
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />

        {/* Thinking Process — step-by-step animation with its own replay */}
        <ThinkingProcess positions={trace.positions} />
      </div>

      {/* Hover popover: the thinking-process tile for this activation, rendered
          in a portal so no scroll container or sibling card can clip it. */}
      {hoveredPos !== null && anchorRect && (() => {
        const entry = entryByPos.get(hoveredPos)
        if (!entry) return null
        const index = trace.positions.findIndex((p) => p.pos === hoveredPos)
        const width = 360
        const margin = 12
        const left = Math.min(
          Math.max(anchorRect.left + anchorRect.width / 2 - width / 2, margin),
          window.innerWidth - width - margin,
        )
        const above = anchorRect.top > window.innerHeight * 0.45
        const style: React.CSSProperties = above
          ? { left, width, bottom: window.innerHeight - anchorRect.top + 10, maxHeight: anchorRect.top - margin - 10 }
          : { left, width, top: anchorRect.bottom + 10, maxHeight: window.innerHeight - anchorRect.bottom - margin - 10 }
        const cos = entry.cos
        return createPortal(
          <div
            style={style}
            className="fixed z-[100] pointer-events-none rounded-xl border border-emerald-500/40 bg-zinc-900/95 light:bg-white/95 backdrop-blur-sm p-4 shadow-2xl shadow-black/70 light:shadow-zinc-400/40 overflow-hidden flex flex-col gap-2.5"
          >
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-500 text-emerald-950 font-mono text-[10px] font-bold flex items-center justify-center">
                {index + 1}
              </span>
              <span className="font-mono text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                activation_{hoveredPos}
              </span>
            </div>
            <div>
              <div className="h-1.5 rounded-full bg-white/10 light:bg-black/10 overflow-hidden">
                <div
                  className="h-full rounded-full bg-emerald-500"
                  style={{ width: `${Math.max(0, Math.min(1, cos ?? 0)) * 100}%` }}
                />
              </div>
              <div className="mt-1.5 flex items-center justify-between font-mono text-[9px]">
                <span className="text-muted-foreground">trust score</span>
                <span className="text-emerald-300 font-bold">{cos != null ? cos.toFixed(3) : '—'}</span>
              </div>
            </div>
            {entry.verb && (
              <div className="overflow-hidden">
                <VerbBreakdown verb={entry.verb} />
              </div>
            )}
          </div>,
          document.body,
        )
      })()}
    </div>
  )
}
