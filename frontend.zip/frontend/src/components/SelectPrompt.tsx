import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowRight, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, PieChart, Search, ShieldAlert, ShieldCheck } from 'lucide-react'
import { loadModels, loadVerdicts } from '../lib/data'
import { useIsMobile } from '../lib/useIsMobile'
import type { DatasetKind, ModelInfo, PromptRow, VerdictInfo } from '../lib/types'

/** Auditing: benign/adversary. Coding: LeetCode difficulty. */
export type TypeFilter = 'all' | 'adversary' | 'benign' | 'Easy' | 'Medium' | 'Hard'

type SortKey = 'id' | 'type' | 'category' | 'question'
type SortDir = 'asc' | 'desc'

const PAGE_SIZE = 10
const TAG_LIMIT = 18

export function formatCategory(cat: string): string {
  return cat.replace(/_/g, ' ').toUpperCase()
}

/** "two-sum" -> "Two Sum" */
export function formatName(taskId: string): string {
  return taskId
    .split('-')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(' ')
}

export const DIFFICULTY_STYLES: Record<string, string> = {
  Easy: 'text-emerald-400 bg-emerald-500/10',
  Medium: 'text-amber-400 bg-amber-500/10',
  Hard: 'text-red-400 bg-red-500/10',
}

/**
 * Pass/fail donut for the model-header stats popover. Status colors match the
 * verdict dots (emerald = pass/valid, red = fail/invalid); the legend carries
 * labels and counts so identity is never color-alone.
 */
function DonutStat({
  passed,
  failed,
  passLabel,
  failLabel,
}: {
  passed: number
  failed: number
  passLabel: string
  failLabel: string
}) {
  const total = passed + failed
  if (total === 0) {
    return <div className="text-xs text-muted-foreground py-4 text-center">No verdict data for the current filter.</div>
  }
  const r = 44
  const C = 2 * Math.PI * r
  // 2px-ish surface gap at each slice boundary (two boundaries when both slices exist).
  const gap = passed > 0 && failed > 0 ? 3 : 0
  const passLen = Math.max((passed / total) * C - gap, 0.5)
  const failLen = Math.max((failed / total) * C - gap, 0.5)
  const pct = Math.round((passed / total) * 100)
  return (
    <div className="flex items-center gap-5">
      <svg width="112" height="112" viewBox="0 0 112 112" role="img" aria-label={`${pct}% ${passLabel.toLowerCase()}`}>
        <g transform="rotate(-90 56 56)">
          <circle cx="56" cy="56" r={r} fill="none" stroke="currentColor" strokeWidth="13" className="text-white/[0.06] light:text-black/[0.08]" />
          {passed > 0 && (
            <circle
              cx="56"
              cy="56"
              r={r}
              fill="none"
              stroke="#10b981"
              strokeWidth="13"
              strokeDasharray={`${passLen} ${C}`}
            >
              <title>{`${passLabel} ${passed}`}</title>
            </circle>
          )}
          {failed > 0 && (
            <circle
              cx="56"
              cy="56"
              r={r}
              fill="none"
              stroke="#ef4444"
              strokeWidth="13"
              strokeDasharray={`${failLen} ${C}`}
              strokeDashoffset={-(passed > 0 ? passLen + gap : 0)}
            >
              <title>{`${failLabel} ${failed}`}</title>
            </circle>
          )}
        </g>
        <text x="56" y="54" textAnchor="middle" fontSize="21" fontWeight="700" fill="currentColor" className="text-foreground">
          {pct}%
        </text>
        <text
          x="56"
          y="70"
          textAnchor="middle"
          fontSize="8.5"
          letterSpacing="0.15em"
          fill="currentColor"
          className="text-muted-foreground uppercase font-bold"
        >
          {passLabel}
        </text>
      </svg>
      <div className="space-y-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
          <span className="text-muted-foreground">{passLabel}</span>
          <span className="ml-auto font-mono font-bold text-foreground pl-3">{passed}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0" />
          <span className="text-muted-foreground">{failLabel}</span>
          <span className="ml-auto font-mono font-bold text-foreground pl-3">{failed}</span>
        </div>
        <div className="pt-1 border-t border-border/60 text-[10px] text-muted-foreground/70">
          {total} with verdicts
        </div>
      </div>
    </div>
  )
}

/** Page-number window: 0-based pages to render, -1 marks an ellipsis gap. */
function pageNumbers(current: number, count: number): number[] {
  if (count <= 7) return Array.from({ length: count }, (_, i) => i)
  const around = [current - 1, current, current + 1].filter((n) => n > 0 && n < count - 1)
  const nums = [0, ...around, count - 1]
  const out: number[] = []
  for (let i = 0; i < nums.length; i++) {
    if (i > 0 && nums[i] - nums[i - 1] > 1) out.push(-1)
    out.push(nums[i])
  }
  return out
}

interface Props {
  prompts: PromptRow[]
  selectedId: string | null
  onSelect: (id: string) => void
  typeFilter: TypeFilter
  onTypeFilter: (f: TypeFilter) => void
  categories: Set<string> | 'all'
  onCategories: (c: Set<string> | 'all') => void
  search: string
  onSearch: (s: string) => void
  onExplore: () => void
  datasetKey?: string
  kind?: DatasetKind
  cot?: boolean
}

export function SelectPrompt({
  prompts,
  selectedId,
  onSelect,
  typeFilter,
  onTypeFilter,
  categories,
  onCategories,
  search,
  onSearch,
  onExplore,
  datasetKey = 'auditing',
  kind = 'auditing',
  cot = false,
}: Props) {
  const isMobile = useIsMobile()
  const [sortKey, setSortKey] = useState<SortKey>('id')
  const [sortDir, setSortDir] = useState<SortDir>('asc')
  const [page, setPage] = useState(0)
  const [showAllCats, setShowAllCats] = useState(false)
  const [models, setModels] = useState<ModelInfo[]>([])
  const [verdicts, setVerdicts] = useState<Record<string, Record<string, VerdictInfo | null | undefined>>>({})
  const [hoveredVerdict, setHoveredVerdict] = useState<{
    modelLabel: string
    verdict: VerdictInfo
    x: number
    y: number
  } | null>(null)
  // Per-model pass/fail stats popovers, toggled by clicking a model header.
  // A Map so several can be open at once for side-by-side comparison.
  const [statsOpen, setStatsOpen] = useState<Map<string, { x: number; y: number }>>(new Map())

  const toggleStats = (key: string, rect: DOMRect) => {
    setStatsOpen((prev) => {
      const next = new Map(prev)
      if (next.has(key)) next.delete(key)
      else next.set(key, { x: rect.left + rect.width / 2, y: rect.bottom })
      return next
    })
  }

  // Any click outside a stats popover / model header closes them all.
  useEffect(() => {
    if (statsOpen.size === 0) return
    const close = () => setStatsOpen(new Map())
    document.addEventListener('click', close)
    return () => document.removeEventListener('click', close)
  }, [statsOpen.size])

  useEffect(() => {
    let cancelled = false
    loadModels(datasetKey).then(async (mods) => {
      if (cancelled) return
      setModels(mods)
      const vMap: Record<string, Record<string, VerdictInfo | null | undefined>> = {}
      for (const m of mods) {
        try {
          vMap[m.key] = await loadVerdicts(datasetKey, m.key)
        } catch (e) {}
      }
      if (!cancelled) setVerdicts(vMap)
    })
    return () => {
      cancelled = true
    }
  }, [datasetKey])

  // Auditing filters by category; coding filters by tag (a row matches if it
  // carries any enabled tag). Coding tags are ordered by frequency so the
  // collapsed chip row shows the most useful ones.
  const allCategories = useMemo(() => {
    if (kind === 'coding') {
      const freq = new Map<string, number>()
      for (const p of prompts) for (const t of p.tags ?? []) freq.set(t, (freq.get(t) ?? 0) + 1)
      return [...freq.keys()].sort((a, b) => freq.get(b)! - freq.get(a)! || a.localeCompare(b))
    }
    return [...new Set(prompts.map((p) => p.category ?? ''))].filter(Boolean).sort()
  }, [prompts, kind])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    const rows = prompts.filter((p) => {
      if (kind === 'coding') {
        if (typeFilter !== 'all' && p.difficulty !== typeFilter) return false
        if (categories !== 'all' && !(p.tags ?? []).some((t) => categories.has(t))) return false
        if (
          q &&
          !(p.name ?? '').replace(/-/g, ' ').toLowerCase().includes(q) &&
          !p.id.toLowerCase().includes(q) &&
          !p.question.toLowerCase().includes(q)
        )
          return false
        return true
      }
      if (typeFilter === 'adversary' && p.is_benign) return false
      if (typeFilter === 'benign' && !p.is_benign) return false
      if (categories !== 'all' && !categories.has(p.category ?? '')) return false
      if (q && !p.question.toLowerCase().includes(q) && !p.id.toLowerCase().includes(q)) return false
      return true
    })
    const dir = sortDir === 'asc' ? 1 : -1
    const diffOrder: Record<string, string> = { Easy: '1', Medium: '2', Hard: '3' }
    const val = (p: PromptRow) => {
      if (kind === 'coding') {
        if (sortKey === 'id') return p.id
        if (sortKey === 'type') return diffOrder[p.difficulty ?? ''] ?? '9'
        if (sortKey === 'category') return formatName(p.name ?? '')
        return (p.tags ?? []).join(', ')
      }
      if (sortKey === 'id') return p.id
      if (sortKey === 'type') return p.is_benign ? 'benign' : 'adversary'
      if (sortKey === 'category') return p.category ?? ''
      return p.question
    }
    return rows.sort((a, b) => val(a).localeCompare(val(b)) * dir)
  }, [prompts, typeFilter, categories, search, sortKey, sortDir, kind])

  // Pagination: the catalogs are large (coding has ~2.9k problems).
  useEffect(() => {
    setPage(0)
  }, [typeFilter, categories, search, sortKey, sortDir, kind])
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const clampedPage = Math.min(page, pageCount - 1)
  const pageRows = filtered.slice(clampedPage * PAGE_SIZE, (clampedPage + 1) * PAGE_SIZE)

  useEffect(() => {
    if (filtered.length > 0 && !filtered.some((p) => p.id === selectedId)) {
      onSelect(filtered[0].id)
    }
  }, [filtered, selectedId, onSelect])

  const toggleCategory = (cat: string) => {
    const next = new Set(categories === 'all' ? allCategories : categories)
    if (next.has(cat)) next.delete(cat)
    else next.add(cat)
    onCategories(next.size === allCategories.length ? 'all' : next)
  }

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else {
      setSortKey(key)
      setSortDir('asc')
    }
  }

  const typeButtons: { key: TypeFilter; label: string; count: number }[] = useMemo(() => {
    if (kind === 'coding') {
      const byDiff = (d: string) => prompts.filter((p) => p.difficulty === d).length
      const buttons: { key: TypeFilter; label: string; count: number }[] = [
        { key: 'all', label: 'All', count: prompts.length },
      ]
      // Difficulty buttons appear only once the data carries a difficulty field.
      if (prompts.some((p) => p.difficulty)) {
        buttons.push(
          { key: 'Easy', label: 'Easy', count: byDiff('Easy') },
          { key: 'Medium', label: 'Medium', count: byDiff('Medium') },
          { key: 'Hard', label: 'Hard', count: byDiff('Hard') },
        )
      }
      return buttons
    }
    return [
      { key: 'all', label: 'All', count: prompts.length },
      { key: 'adversary', label: 'Adversary', count: prompts.filter((p) => !p.is_benign).length },
      { key: 'benign', label: 'Benign', count: prompts.filter((p) => p.is_benign).length },
    ]
  }, [prompts, kind])

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey !== col ? (
      <ArrowUpDown className="w-3 h-3 text-muted-foreground/40" />
    ) : sortDir === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-emerald-400" />
    ) : (
      <ArrowDown className="w-3 h-3 text-emerald-400" />
    )

  const th = 'px-3 py-3.5 text-left font-bold uppercase tracking-wider text-[11px] text-muted-foreground select-none'

  // On mobile the CTA sits above the list so it's reachable without scrolling
  // past the whole page of cards; on desktop it stays centered below the table.
  const exploreButton = (
    <div className="flex justify-center">
      <button
        onClick={onExplore}
        disabled={!selectedId}
        className="inline-flex items-center gap-2 rounded-full bg-emerald-500 text-emerald-950 font-bold px-8 h-12 shadow-lg shadow-emerald-500/20 hover:scale-105 hover:-translate-y-0.5 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {cot ? 'Explore Thinking' : kind === 'coding' ? 'Explore Problem' : 'Explore Prompt'}
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  )

  return (
    <div className="space-y-6">
      {hoveredVerdict && (
        <div
          style={{
            left: Math.min(hoveredVerdict.x, typeof window !== 'undefined' ? window.innerWidth - 330 : 500),
            top: hoveredVerdict.y > 180 ? hoveredVerdict.y - 10 : hoveredVerdict.y + 24,
            transform: hoveredVerdict.y > 180 ? 'translateY(-100%)' : 'none',
          }}
          className="fixed z-[200] w-80 p-3.5 text-xs leading-relaxed text-foreground bg-card/95 backdrop-blur-md border border-border rounded-xl shadow-2xl pointer-events-none break-words whitespace-normal animate-in fade-in duration-150"
        >
          <div className="font-bold uppercase tracking-wider text-[10px] mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${hoveredVerdict.verdict.is_invalid ? 'bg-red-500' : 'bg-emerald-500'}`} />
              {hoveredVerdict.verdict.total_cases != null
                ? hoveredVerdict.verdict.is_invalid
                  ? 'Test Cases Failed'
                  : 'All Test Cases Passed'
                : hoveredVerdict.verdict.is_invalid
                  ? 'Invalid Answer Verdict'
                  : 'Valid Answer Verdict'}
            </span>
            <span className="text-muted-foreground/80">{hoveredVerdict.modelLabel}</span>
          </div>
          <div className="text-muted-foreground font-medium">
            {hoveredVerdict.verdict.total_cases != null ? (
              <>
                Passed{' '}
                <span className={hoveredVerdict.verdict.is_invalid ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {hoveredVerdict.verdict.passed_cases ?? '—'} / {hoveredVerdict.verdict.total_cases}
                </span>{' '}
                test cases.
              </>
            ) : (
              hoveredVerdict.verdict.reason ||
              (hoveredVerdict.verdict.is_invalid
                ? 'Answer marked as invalid by evaluation judge.'
                : 'Answer marked as compliant and valid by evaluation judge.')
            )}
          </div>
        </div>
      )}

      {/* Model stats popovers: one per toggled model header, laid out
          side-by-side (never overlapping) so models can be compared. */}
      {statsOpen.size > 0 &&
        (() => {
          const W = 300
          const GAP = 10
          const open = models.filter((m) => statsOpen.has(m.key))
          let prevRight = -Infinity
          return open.map((m) => {
            const anchor = statsOpen.get(m.key)!
            let left = Math.max(12, Math.min(anchor.x - W / 2, window.innerWidth - W - 12))
            if (left < prevRight + GAP) left = Math.min(prevRight + GAP, window.innerWidth - W - 12)
            prevRight = left + W
            let passed = 0
            let failed = 0
            for (const p of filtered) {
              const v = verdicts[m.key]?.[p.id]
              if (v == null) continue
              if (v.is_invalid) failed++
              else passed++
            }
            return (
              <div
                key={m.key}
                onClick={(e) => e.stopPropagation()}
                style={{ left, top: anchor.y + 10, width: W }}
                className="fixed z-[200] p-4 bg-card/95 backdrop-blur-md border border-border rounded-xl shadow-2xl animate-in fade-in duration-150"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="font-bold uppercase tracking-wider text-[10px] text-foreground">{m.label}</span>
                  <span className="text-[10px] text-muted-foreground/70">
                    {filtered.length === prompts.length ? 'whole dataset' : `filtered · ${filtered.length} rows`}
                  </span>
                </div>
                <DonutStat
                  passed={passed}
                  failed={failed}
                  passLabel={kind === 'coding' ? 'Passed' : 'Valid'}
                  failLabel={kind === 'coding' ? 'Failed' : 'Invalid'}
                />
              </div>
            )
          })
        })()}

      <div className="rounded-2xl border border-border bg-card/60 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground mr-2">
              {kind === 'coding' ? 'Difficulty' : 'Type'}
            </span>
            {typeButtons.map((b) => {
              const active = typeFilter === b.key
              return (
                <button
                  key={b.key}
                  onClick={() => onTypeFilter(b.key)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-emerald-500 text-emerald-950 shadow-md shadow-emerald-500/20'
                      : 'bg-secondary/50 text-muted-foreground hover:bg-secondary hover:text-foreground'
                  }`}
                >
                  {b.label}{' '}
                  <span className={`ml-1 text-[10px] ${active ? 'text-emerald-950/70 font-bold' : 'text-muted-foreground/60'}`}>
                    {b.count}
                  </span>
                </button>
              )
            })}
          </div>

          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              placeholder={kind === 'coding' ? 'Search problem name or ID…' : 'Search prompt text or ID…'}
              className="w-full bg-secondary/40 border border-border rounded-full pl-10 pr-4 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
            />
          </div>
        </div>

        {/* Category / tag filter — hidden in mobile mode */}
        <div className="pt-3 border-t border-border/60 hidden sm:flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground/70 mr-2">
            {kind === 'coding' ? 'Tags' : 'Category'}
          </span>
          <button
            onClick={() => onCategories(categories === 'all' ? new Set() : 'all')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
              categories === 'all'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-secondary/30 text-muted-foreground hover:bg-secondary/60 hover:text-foreground'
            }`}
          >
            All
          </button>
          {(kind === 'coding' && !showAllCats ? allCategories.slice(0, TAG_LIMIT) : allCategories).map((cat) => {
            const active = categories === 'all' || categories.has(cat)
            return (
              <button
                key={cat}
                onClick={() => toggleCategory(cat)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                  active
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-transparent text-muted-foreground/60 border-border hover:text-foreground hover:bg-secondary/30'
                }`}
              >
                {kind === 'coding' ? cat : formatCategory(cat)}
              </button>
            )
          })}
          {kind === 'coding' && allCategories.length > TAG_LIMIT && (
            <button
              onClick={() => setShowAllCats((s) => !s)}
              className="px-2.5 py-1 rounded-md text-[11px] font-bold text-emerald-400/80 hover:text-emerald-300 transition-colors cursor-pointer"
            >
              {showAllCats ? 'Show less' : `+${allCategories.length - TAG_LIMIT} more`}
            </button>
          )}
        </div>
      </div>

      {isMobile && exploreButton}

      <div className="rounded-2xl border border-border bg-card/40 overflow-hidden shadow-sm">
        {isMobile ? (
          /* Mobile: one stacked card per row — the wide table doesn't fit a phone */
          <div className="max-h-[520px] overflow-y-auto scrollbar-thin">
            {pageRows.map((p) => {
              const selected = p.id === selectedId
              return (
                <div
                  key={p.id}
                  onClick={() => onSelect(p.id)}
                  className={`px-4 py-3 border-b border-white/5 light:border-black/5 cursor-pointer transition-colors space-y-1.5 ${
                    selected ? 'bg-emerald-500/[0.07]' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`relative flex items-center justify-center w-4 h-4 shrink-0 rounded-full border-2 transition-all duration-300 ${
                        selected ? 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'border-muted-foreground/40'
                      }`}
                    >
                      {selected && (
                        <motion.span
                          layoutId="prompt-radio-dot"
                          className="w-2 h-2 rounded-full bg-emerald-500"
                          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                        />
                      )}
                    </span>
                    <span className="font-mono text-xs text-muted-foreground font-semibold">{p.id}</span>
                    {kind === 'coding' ? (
                      p.difficulty && (
                        <span
                          className={`inline-flex items-center text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                            DIFFICULTY_STYLES[p.difficulty] ?? 'text-muted-foreground bg-secondary/40'
                          }`}
                        >
                          {p.difficulty}
                        </span>
                      )
                    ) : p.is_benign ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase px-1.5 py-0.5 rounded text-emerald-400 bg-emerald-500/10">
                        <ShieldCheck className="w-3 h-3 shrink-0" /> BEN
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase px-1.5 py-0.5 rounded text-red-400 bg-red-500/10">
                        <ShieldAlert className="w-3 h-3 shrink-0" /> ADV
                      </span>
                    )}
                    {/* Per-model verdict dots, labeled by the model's first name */}
                    <span className="ml-auto flex items-center gap-2">
                      {models.map((m) => {
                        const v = verdicts[m.key]?.[p.id]
                        return (
                          <span key={m.key} className="inline-flex items-center gap-1">
                            <span className="text-[9px] font-bold uppercase text-muted-foreground/60">
                              {m.label.split(' ')[0]}
                            </span>
                            {v ? (
                              <span
                                className={`inline-block w-2.5 h-2.5 rounded-full ${
                                  v.is_invalid ? 'bg-red-500' : 'bg-emerald-500'
                                }`}
                              />
                            ) : (
                              <span className="text-muted-foreground/30 text-[10px] font-mono">-</span>
                            )}
                          </span>
                        )
                      })}
                    </span>
                  </div>
                  {kind === 'coding' ? (
                    <div className={`text-sm font-medium truncate ${selected ? 'text-foreground' : 'text-foreground/80'}`}>
                      {formatName(p.name ?? '')}
                    </div>
                  ) : (
                    <p
                      className={`text-sm leading-relaxed line-clamp-2 ${
                        selected ? 'text-foreground font-medium' : 'text-muted-foreground'
                      }`}
                    >
                      {p.question}
                    </p>
                  )}
                </div>
              )
            })}
            {filtered.length === 0 && (
              <div className="px-4 py-12 text-center text-muted-foreground">No prompts match the current filters.</div>
            )}
          </div>
        ) : (
        <div className="overflow-x-auto max-h-[520px] overflow-y-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10 bg-card">
              <tr className="border-b border-border">
                <th className={`${th} w-10`} />
                <th className={`${th} w-14`}>
                  <button onClick={() => toggleSort('id')} className="flex items-center gap-1 cursor-pointer hover:text-foreground">
                    ID <SortIcon col="id" />
                  </button>
                </th>
                <th className={`${th} w-16`}>
                  <button onClick={() => toggleSort('type')} className="flex items-center gap-1 cursor-pointer hover:text-foreground">
                    {kind === 'coding' ? 'Diff.' : 'Type'} <SortIcon col="type" />
                  </button>
                </th>
                <th className={`${th} ${kind === 'coding' ? 'w-[27rem]' : 'w-28'}`}>
                  <button onClick={() => toggleSort('category')} className="flex items-center gap-1 cursor-pointer hover:text-foreground">
                    {kind === 'coding' ? 'Problem Name' : 'Cat.'} <SortIcon col="category" />
                  </button>
                </th>
                {models.map((m) => (
                  <th key={m.key} className={`${th} w-14 text-center`}>
                    <button
                      title={`${m.label} — click for ${kind === 'coding' ? 'pass/fail' : 'valid/invalid'} stats`}
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleStats(m.key, e.currentTarget.getBoundingClientRect())
                      }}
                      className={`inline-flex items-center gap-1 cursor-pointer font-bold transition-colors ${
                        statsOpen.has(m.key) ? 'text-emerald-400' : 'text-foreground/90 hover:text-emerald-400'
                      }`}
                    >
                      {m.label.split(' ')[0]}
                      <PieChart className="w-3 h-3 opacity-60" />
                    </button>
                  </th>
                ))}
                <th className={`${th} w-full`}>
                  <button onClick={() => toggleSort('question')} className="flex items-center gap-1 cursor-pointer hover:text-foreground">
                    {kind === 'coding' ? 'Tags' : 'Prompt Text'} <SortIcon col="question" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody>
              {pageRows.map((p) => {
                const selected = p.id === selectedId
                return (
                  <tr
                    key={p.id}
                    onClick={() => onSelect(p.id)}
                    onDoubleClick={() => {
                      onSelect(p.id)
                      onExplore()
                    }}
                    className={`border-b border-white/5 light:border-black/5 cursor-pointer transition-colors ${
                      selected ? 'bg-emerald-500/[0.07]' : 'hover:bg-white/[0.03] light:hover:bg-black/[0.02]'
                    }`}
                  >
                    <td className="px-3 py-3">
                      <span
                        className={`relative flex items-center justify-center w-4 h-4 rounded-full border-2 transition-all duration-300 ${
                          selected ? 'border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'border-muted-foreground/40'
                        }`}
                      >
                        {selected && (
                          <motion.span
                            layoutId="prompt-radio-dot"
                            className="w-2 h-2 rounded-full bg-emerald-500"
                            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                          />
                        )}
                      </span>
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-muted-foreground font-semibold">{p.id}</td>
                    <td className="px-3 py-3">
                      {kind === 'coding' ? (
                        p.difficulty ? (
                          <span
                            className={`inline-flex items-center text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                              DIFFICULTY_STYLES[p.difficulty] ?? 'text-muted-foreground bg-secondary/40'
                            }`}
                          >
                            {p.difficulty}
                          </span>
                        ) : (
                          <span className="text-muted-foreground/30 text-xs font-mono">-</span>
                        )
                      ) : p.is_benign ? (
                        <span
                          title="Benign"
                          className="inline-flex items-center gap-1 text-[10px] font-bold uppercase px-1.5 py-0.5 rounded text-emerald-400 bg-emerald-500/10"
                        >
                          <ShieldCheck className="w-3 h-3 shrink-0" /> BEN
                        </span>
                      ) : (
                        <span
                          title="Adversary"
                          className="inline-flex items-center gap-1 text-[10px] font-bold uppercase px-1.5 py-0.5 rounded text-red-400 bg-red-500/10"
                        >
                          <ShieldAlert className="w-3 h-3 shrink-0" /> ADV
                        </span>
                      )}
                    </td>
                    {kind === 'coding' ? (
                      <td
                        className={`px-3 py-3 font-medium max-w-[420px] truncate ${selected ? 'text-foreground' : 'text-foreground/80'}`}
                        title={formatName(p.name ?? '')}
                      >
                        <a
                          href={`https://leetcode.com/problems/${p.name}/`}
                          target="_blank"
                          rel="noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="hover:text-emerald-400 hover:underline underline-offset-2 transition-colors"
                        >
                          {formatName(p.name ?? '')}
                        </a>
                      </td>
                    ) : (
                      <td className="px-3 py-3 text-[10px] font-bold uppercase tracking-wider text-muted-foreground max-w-[120px] sm:max-w-[140px] truncate" title={formatCategory(p.category ?? '')}>
                        {formatCategory(p.category ?? '')}
                      </td>
                    )}
                    {models.map((m) => {
                      const v = verdicts[m.key]?.[p.id]
                      return (
                        <td key={m.key} className="px-3 py-3 text-center">
                          {v ? (
                            <span
                              onMouseEnter={(e) => {
                                const rect = e.currentTarget.getBoundingClientRect()
                                setHoveredVerdict({
                                  modelLabel: m.label,
                                  verdict: v,
                                  x: rect.left,
                                  y: rect.top,
                                })
                              }}
                              onMouseLeave={() => setHoveredVerdict(null)}
                              className={`inline-block w-3 h-3 rounded-full cursor-help transition-transform hover:scale-125 ${
                                v.is_invalid
                                  ? 'bg-red-500 shadow-md shadow-red-500/50 ring-2 ring-red-500/20'
                                  : 'bg-emerald-500 shadow-md shadow-emerald-500/50 ring-2 ring-emerald-500/20'
                              }`}
                            />
                          ) : (
                            <span className="text-muted-foreground/30 text-xs font-mono">-</span>
                          )}
                        </td>
                      )
                    })}
                    {kind === 'coding' ? (
                      <td className="px-4 py-3">
                        <span className="flex flex-wrap gap-1" title={(p.tags ?? []).join(', ')}>
                          {(p.tags ?? []).slice(0, 5).map((t) => (
                            <span
                              key={t}
                              className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground whitespace-nowrap"
                            >
                              {t}
                            </span>
                          ))}
                          {(p.tags ?? []).length > 5 && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-secondary/30 text-muted-foreground/70 whitespace-nowrap">
                              +{(p.tags ?? []).length - 5}
                            </span>
                          )}
                        </span>
                      </td>
                    ) : (
                      <td className={`px-4 py-3 leading-relaxed ${selected ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                        {p.question}
                      </td>
                    )}
                  </tr>
                )
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5 + models.length} className="px-4 py-12 text-center text-muted-foreground">
                    No prompts match the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        )}

        {/* Pagination footer */}
        {filtered.length > PAGE_SIZE && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-t border-border bg-card/60">
            <span className="text-[11px] text-muted-foreground font-mono">
              {clampedPage * PAGE_SIZE + 1}–{Math.min((clampedPage + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(clampedPage - 1)}
                disabled={clampedPage === 0}
                aria-label="Previous page"
                className="w-7 h-7 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              {pageNumbers(clampedPage, pageCount).map((n, i) =>
                n === -1 ? (
                  <span key={`gap-${i}`} className="px-1 text-muted-foreground/50 text-xs select-none">
                    …
                  </span>
                ) : (
                  <button
                    key={n}
                    onClick={() => setPage(n)}
                    className={`min-w-7 h-7 px-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                      n === clampedPage
                        ? 'bg-emerald-500 text-emerald-950'
                        : 'text-muted-foreground hover:text-foreground hover:bg-secondary/60'
                    }`}
                  >
                    {n + 1}
                  </button>
                ),
              )}
              <button
                onClick={() => setPage(clampedPage + 1)}
                disabled={clampedPage >= pageCount - 1}
                aria-label="Next page"
                className="w-7 h-7 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {!isMobile && exploreButton}
    </div>
  )
}
