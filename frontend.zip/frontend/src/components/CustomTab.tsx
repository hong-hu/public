import { motion } from 'framer-motion'
import { FlaskConical, Sparkles } from 'lucide-react'

export function CustomTab() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="max-w-3xl mx-auto"
    >
      <div className="rounded-2xl border border-dashed border-border bg-card/40 px-8 py-20 text-center">
        <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
          <FlaskConical className="w-7 h-7 text-emerald-400" />
        </div>
        <h2 className="mt-6 text-xl font-bold">Custom Prompts</h2>
        <p className="mt-3 text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
          Soon you will be able to run your own prompt through the Activation Verbalizer and watch
          the model’s latent thinking unfold live.
        </p>
        <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 text-xs font-bold uppercase tracking-widest text-muted-foreground">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          Coming Soon
        </div>
      </div>
    </motion.section>
  )
}
