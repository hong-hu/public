import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { ChevronDown, Cpu, MessageSquare, ShieldAlert, ShieldCheck } from 'lucide-react'
import { loadModels } from '../lib/data'
import { useIsMobile } from '../lib/useIsMobile'
import type { DatasetKind, ModelInfo, PromptRow } from '../lib/types'
import { ModelBucket } from './ModelBucket'
import { ProblemStatement } from './ProblemStatement'
import { DIFFICULTY_STYLES, formatCategory, formatName } from './SelectPrompt'

export function ExplorePrompt({
  prompt,
  datasetKey = 'auditing',
  kind = 'auditing',
  cot = false,
}: {
  prompt: PromptRow
  datasetKey?: string
  kind?: DatasetKind
  cot?: boolean
}) {
  const isMobile = useIsMobile()
  const [models, setModels] = useState<ModelInfo[] | null>(null)
  const [enabled, setEnabled] = useState<Set<string> | 'all'>('all')
  const [error, setError] = useState<string | null>(null)
  // Coding problem statements are long — collapsed by default, expandable.
  const [problemOpen, setProblemOpen] = useState(false)

  useEffect(() => {
    setModels(null)
    setError(null)
    loadModels(datasetKey)
      .then((mods) => {
        setModels(mods)
        // One bucket by default (Qwen) in both tabs; others are a toggle away.
        const qwen = mods.find((m) => m.key.includes('qwen'))
        setEnabled(qwen ? new Set([qwen.key]) : 'all')
      })
      .catch((e) => setError(String(e)))
  }, [datasetKey, kind])

  // Entering mobile mode (or landing there) collapses a multi-selection to
  // the first enabled model.
  useEffect(() => {
    if (!isMobile || !models) return
    setEnabled((cur) => {
      if (cur !== 'all' && cur.size <= 1) return cur
      const first = models.find((m) => cur === 'all' || cur.has(m.key))
      return first ? new Set([first.key]) : cur
    })
  }, [isMobile, models])

  if (error) return <div className="text-center text-destructive py-20">{error}</div>
  if (!models) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping mr-3" />
        Loading models…
      </div>
    )
  }

  const isEnabled = (key: string) => enabled === 'all' || enabled.has(key)
  const toggleModel = (key: string) => {
    // Mobile mode fits one bucket: model buttons act as radios, so picking
    // one automatically deselects the other.
    if (isMobile) {
      setEnabled(new Set([key]))
      return
    }
    const next = new Set(enabled === 'all' ? models.map((m) => m.key) : enabled)
    if (next.has(key)) next.delete(key)
    else next.add(key)
    setEnabled(next.size === models.length ? 'all' : next)
  }
  const visible = models.filter((m) => isEnabled(m.key))

  return (
    <div className="space-y-6">
      {/* Model toggles */}
      <div className="rounded-2xl border border-border bg-card/60 p-5 flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60 mr-2">
          <Cpu className="w-3.5 h-3.5" /> Models
        </span>
        {!isMobile && (
          <button
            onClick={() => setEnabled(enabled === 'all' ? new Set() : 'all')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              enabled === 'all'
                ? 'bg-emerald-500 text-emerald-950 shadow-lg shadow-emerald-500/20'
                : 'bg-secondary/50 text-muted-foreground hover:bg-secondary hover:text-foreground'
            }`}
          >
            All
          </button>
        )}
        {models.map((m) => {
          const on = isEnabled(m.key)
          return (
            <button
              key={m.key}
              onClick={() => toggleModel(m.key)}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer border ${
                on
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25'
                  : 'bg-transparent text-muted-foreground/60 border-border hover:text-foreground'
              }`}
            >
              <span className={`inline-block w-1.5 h-1.5 rounded-full mr-2 ${on ? 'bg-emerald-400' : 'bg-muted-foreground/40'}`} />
              {m.label}
            </button>
          )
        })}
      </div>

      {/* Unified prompt — the same input sequence is fed to every model */}
      <div className="rounded-2xl border border-border bg-card/60 p-5 space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60">
            <MessageSquare className="w-3.5 h-3.5" /> {kind === 'coding' ? 'Problem' : 'Prompt'}
          </span>
          <span className="font-mono text-xs text-muted-foreground bg-secondary/50 px-2.5 py-1 rounded-full">
            #{prompt.id}
          </span>
          {kind === 'coding' ? (
            <>
              <a
                href={`https://leetcode.com/problems/${prompt.name}/`}
                target="_blank"
                rel="noreferrer"
                className="font-semibold text-sm text-foreground hover:text-emerald-400 hover:underline underline-offset-2 transition-colors"
              >
                {formatName(prompt.name ?? '')}
              </a>
              {prompt.difficulty && (
                <span
                  className={`inline-flex items-center text-[10px] font-bold uppercase px-2 py-1 rounded-full ${
                    DIFFICULTY_STYLES[prompt.difficulty] ?? 'text-muted-foreground bg-secondary/40'
                  }`}
                >
                  {prompt.difficulty}
                </span>
              )}
              {(prompt.tags ?? []).map((t) => (
                <span key={t} className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground">
                  {t}
                </span>
              ))}
              <button
                onClick={() => setProblemOpen((o) => !o)}
                className="ml-auto inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-emerald-400 transition-colors cursor-pointer"
              >
                {problemOpen ? 'Hide Problem' : 'Show Problem'}
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${problemOpen ? 'rotate-180' : ''}`} />
              </button>
            </>
          ) : (
            <>
              {prompt.is_benign ? (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400">
                  <ShieldCheck className="w-3 h-3" /> Benign
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase px-2 py-1 rounded-full bg-red-500/10 text-red-400">
                  <ShieldAlert className="w-3 h-3" /> Adversary
                </span>
              )}
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {formatCategory(prompt.category ?? '')}
              </span>
            </>
          )}
        </div>
        {kind === 'coding' ? (
          // LeetCode prompts are long (description + starter code) — collapsed
          // by default; rendered LeetCode-style by ProblemStatement.
          problemOpen && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 rounded-xl bg-secondary/30 border border-border max-h-96 overflow-y-auto scrollbar-thin"
            >
              <ProblemStatement text={prompt.question} />
            </motion.div>
          )
        ) : (
          <div className="p-5 rounded-xl bg-secondary/30 border border-border text-foreground font-medium leading-relaxed">
            “{prompt.question}”
          </div>
        )}
      </div>

      {/* One bucket per model */}
      {visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border py-16 text-center text-muted-foreground">
          Toggle at least one model to explore its latent mind.
        </div>
      ) : (
        <div
          className={`grid gap-8 items-start ${
            visible.length === 1 ? '' : visible.length === 2 ? 'lg:grid-cols-2' : 'lg:grid-cols-2 2xl:grid-cols-3'
          }`}
        >
          {visible.map((m, i) => (
            <motion.div
              key={m.key}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
            >
              <ModelBucket model={m} prompt={prompt} datasetKey={datasetKey} kind={kind} cot={cot} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
