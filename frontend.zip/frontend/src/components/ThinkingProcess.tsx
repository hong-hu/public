import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Brain, RotateCcw, Volume2 } from 'lucide-react'
import type { PositionEntry } from '../lib/types'
import { VerbPhrase, getVerbPhrase } from './VerbBreakdown'

// Milliseconds between step reveals — deliberate enough to read as "thinking".
const STEP_MS = 900

/**
 * Step-by-step animated view of the activation-verbalizer thinking process.
 * Each step: its numbered node pops in, the connector draws down from the
 * previous node, and the card slides in as the "active" thought; when the next
 * step starts, the previous one settles. Node numbers match the marker rail
 * next to the Observed Generation (same position order, same styling).
 * Replayable via its own Replay button, independent of the Observed
 * Generation replay.
 */
export function ThinkingProcess({ positions }: { positions: PositionEntry[] }) {
  // Number by the full position list so node numbers line up with the
  // Observed Generation marker rail even if a position has no verb.
  const steps = positions
    .map((entry, i) => ({ entry, num: i + 1 }))
    .filter((s) => s.entry.verb)
  const [revealed, setRevealed] = useState(0)
  const [localRun, setLocalRun] = useState(0)
  const [hoveredTile, setHoveredTile] = useState<number | null>(null)
  const [speakingPos, setSpeakingPos] = useState<number | null>(null)

  // Read a thought card aloud via the browser's built-in TTS. Clicking the
  // card that's currently speaking stops it; clicking another card switches.
  const speak = (pos: number, text: string | null) => {
    if (!text || !('speechSynthesis' in window)) return
    speechSynthesis.cancel()
    if (speakingPos === pos) {
      setSpeakingPos(null)
      return
    }
    const u = new SpeechSynthesisUtterance(text)
    u.onend = () => setSpeakingPos((p) => (p === pos ? null : p))
    u.onerror = () => setSpeakingPos((p) => (p === pos ? null : p))
    speechSynthesis.speak(u)
    setSpeakingPos(pos)
  }

  // Stop speech when the component unmounts (e.g. navigating away).
  useEffect(() => () => speechSynthesis.cancel(), [])

  useEffect(() => {
    setRevealed(0)
    if (steps.length === 0) return
    const interval = setInterval(() => {
      setRevealed((c) => {
        if (c + 1 >= steps.length) clearInterval(interval)
        return Math.min(c + 1, steps.length)
      })
    }, STEP_MS)
    return () => clearInterval(interval)
  }, [steps.length, localRun])

  const running = steps.length > 0 && revealed < steps.length

  return (
    <div className="space-y-3">
      {/* Section header: label + replay */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60">
          <Brain className={`w-3 h-3 ${running ? 'text-emerald-400 animate-pulse' : ''}`} />
          <span>Thinking Process</span>
        </div>
        <button
          onClick={() => setLocalRun((r) => r + 1)}
          className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-emerald-400 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Replay
        </button>
      </div>

      <div key={localRun}>
        {steps.map(({ entry: p, num }, i) => {
          const visible = i < revealed
          const active = running && i === revealed - 1
          const hovered = hoveredTile === p.pos
          if (!visible) return null
          return (
            <motion.div
              key={p.pos}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              {/* Node column: numbered dot + connector drawing down to the next step */}
              <div className="flex flex-col items-center w-8 shrink-0">
                <motion.div
                  initial={{ scale: 0.3, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', stiffness: 420, damping: 22 }}
                  className={`relative w-7 h-7 rounded-full border flex items-center justify-center font-mono text-[11px] font-bold transition-colors duration-500 ${
                    active
                      ? 'bg-emerald-500 text-emerald-950 border-emerald-300'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/40'
                  }`}
                >
                  {/* Radar ping while this step is the active thought */}
                  {active && (
                    <motion.span
                      className="absolute inset-0 rounded-full border-2 border-emerald-400"
                      animate={{ scale: [1, 1.9], opacity: [0.7, 0] }}
                      transition={{ duration: 1.1, repeat: Infinity, ease: 'easeOut' }}
                    />
                  )}
                  {num}
                </motion.div>
                {i < steps.length - 1 && (
                  <motion.div
                    initial={{ scaleY: 0 }}
                    animate={{ scaleY: i < revealed - 1 ? 1 : 0 }}
                    transition={{ duration: 0.45, ease: 'easeOut' }}
                    style={{ transformOrigin: 'top' }}
                    className="w-px flex-1 min-h-4 bg-gradient-to-b from-emerald-400/70 to-emerald-500/25"
                  />
                )}
              </div>

              {/* Thought card */}
              <motion.div
                initial={{ opacity: 0, x: -18, scale: 0.98 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1], delay: 0.12 }}
                onMouseEnter={() => setHoveredTile(p.pos)}
                onMouseLeave={() => setHoveredTile(null)}
                onClick={() => speak(p.pos, getVerbPhrase(p.verb))}
                className={`relative flex-1 rounded-xl border p-4 mb-3 cursor-pointer transition-all duration-500 ${
                  hovered
                    ? 'border-emerald-500/60 bg-emerald-500/[0.08] glow-active'
                    : active
                      ? 'border-emerald-500/50 bg-emerald-500/[0.06] shadow-[0_0_24px_rgba(16,185,129,0.12)]'
                      : 'border-border bg-card/50 hover:border-emerald-500/30'
                }`}
              >
                {(hovered || speakingPos === p.pos) && (
                  <Volume2
                    className={`absolute top-2.5 right-2.5 w-3.5 h-3.5 ${
                      speakingPos === p.pos ? 'text-emerald-400 animate-pulse' : 'text-muted-foreground/50'
                    }`}
                  />
                )}
                <div className="max-h-56 overflow-y-auto scrollbar-thin pr-1">
                  <VerbPhrase verb={p.verb!} />
                </div>
              </motion.div>
            </motion.div>
          )
        })}

        {/* Upcoming-thought indicator while the sequence is still unfolding */}
        <AnimatePresence>
          {running && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex gap-3 items-center"
            >
              <div className="flex flex-col items-center w-8 shrink-0">
                <div className="w-7 h-7 rounded-full border border-dashed border-emerald-500/40 flex items-center justify-center">
                  <div className="flex gap-0.5">
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        className="w-1 h-1 rounded-full bg-emerald-400"
                        animate={{ opacity: [0.2, 1, 0.2] }}
                        transition={{ duration: 1, repeat: Infinity, delay: d * 0.2 }}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-emerald-500/50 lowercase tracking-widest mb-1">
                _verbalizing_next_activation...
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {steps.length === 0 && (
          <div className="text-sm text-muted-foreground py-4">No verbalized activations for this prompt.</div>
        )}
      </div>
    </div>
  )
}
