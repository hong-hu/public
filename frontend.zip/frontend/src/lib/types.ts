export type DatasetKind = 'auditing' | 'coding'

export interface PromptRow {
  id: string
  question: string
  // auditing datasets
  category?: string
  is_benign?: boolean
  // coding datasets
  name?: string // raw task_id, e.g. "two-sum"
  difficulty?: string | null // "Easy" | "Medium" | "Hard", null until data provides it
  tags?: string[]
}

export interface ModelInfo {
  key: string
  label: string
}

export interface DatasetInfo {
  key: string
  label: string
  kind?: DatasetKind
  /** Chain-of-thought dataset: traces carry a thinking transcript and the
      activation positions describe the thinking, not the answer. */
  cot?: boolean
}

export interface VerbSections {
  format?: string | null
  phrase?: string | null
  intent?: string | null
  expectation?: string | null
  extra?: string[]
}

export interface PositionEntry {
  pos: number
  cos: number | null
  verb: VerbSections | string | null
}

export interface VerdictInfo {
  is_invalid: boolean
  reason: string
  // coding datasets: judge is a test runner
  passed_cases?: number | null
  total_cases?: number | null
}

export interface PromptTrace {
  answer: string
  /** cot datasets: one sentence per line; position 1 marks the point right
      after the prompt, positions 2… mark the end of each thinking line. */
  thinking?: string
  verdict?: VerdictInfo | null
  positions: PositionEntry[]
}

export type ModelBundle = Record<string, PromptTrace>
