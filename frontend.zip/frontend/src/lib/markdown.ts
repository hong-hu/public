import type { AnswerWord } from './positions'

/**
 * Word-level markdown layout for the Observed Generation view.
 *
 * The answer must keep streaming word by word, and activation highlights and
 * popovers are keyed by word index into `splitWords(answer)`. So instead of
 * handing the text to a markdown renderer (which would destroy the word
 * mapping), we annotate each existing word with block/inline markdown info:
 * the word order and indices never change, only how each word is displayed.
 */

export interface MdWord {
  /** Index into the original splitWords() array — highlight keys stay valid. */
  index: number
  /** Display text with markdown delimiters (`**`, `` ` ``, …) stripped. */
  text: string
  bold: boolean
  italic: boolean
  code: boolean
  /** Pure-syntax token (bullet marker, fence, heading hashes) — not rendered. */
  hidden: boolean
  /** Starts a new line inside a code block. */
  newline: boolean
}

export interface MdBlock {
  type: 'p' | 'h1' | 'h2' | 'h3' | 'li' | 'code' | 'hr'
  /** List marker to render for 'li' ("•" or the original "1." / "2)"). */
  marker?: string
  words: MdWord[]
}

interface Range {
  start: number
  end: number
}

const inRanges = (ranges: Range[], i: number) => ranges.some((r) => i >= r.start && i < r.end)

/**
 * Find inline code/bold/italic ranges in one line (absolute char offsets).
 * Each pass masks its matches so the next pass can't re-match delimiters
 * (e.g. italic matching the inner `*` of a `**bold**` pair).
 */
function inlineRanges(text: string, base: number) {
  const del: Range[] = []
  const bold: Range[] = []
  const italic: Range[] = []
  const code: Range[] = []
  let masked = text
  const mask = (start: number, len: number) => {
    masked = masked.slice(0, start) + ' '.repeat(len) + masked.slice(start + len)
  }
  const scan = (re: RegExp, delim: number, out: Range[]) => {
    let m: RegExpExecArray | null
    while ((m = re.exec(masked)) !== null) {
      const s = m.index
      const e = s + m[0].length
      del.push({ start: base + s, end: base + s + delim })
      del.push({ start: base + e - delim, end: base + e })
      out.push({ start: base + s + delim, end: base + e - delim })
      mask(s, m[0].length)
      re.lastIndex = s + m[0].length
    }
  }
  scan(/`[^`]+`/g, 1, code)
  scan(/\*\*[^*]+\*\*/g, 2, bold)
  scan(/__[^_]+__/g, 2, bold)
  scan(/\*[^*\s][^*]*\*/g, 1, italic)
  return { del, bold, italic, code }
}

/** Words of one line annotated with inline styles, delimiters stripped. */
function styleLine(
  lineText: string,
  lineStart: number,
  lineWords: { word: AnswerWord; index: number }[],
  skipFirst: boolean,
): MdWord[] {
  const { del, bold, italic, code } = inlineRanges(lineText, lineStart)
  return lineWords.map(({ word, index }, i) => {
    if (skipFirst && i === 0) {
      return { index, text: '', bold: false, italic: false, code: false, hidden: true, newline: false }
    }
    let text = ''
    let isBold = false
    let isItalic = false
    let isCode = false
    for (let c = 0; c < word.text.length; c++) {
      const abs = word.start + c
      if (inRanges(del, abs)) continue
      text += word.text[c]
      if (inRanges(bold, abs)) isBold = true
      if (inRanges(italic, abs)) isItalic = true
      if (inRanges(code, abs)) isCode = true
    }
    return { index, text, bold: isBold, italic: isItalic, code: isCode, hidden: text.length === 0, newline: false }
  })
}

export function parseMarkdownBlocks(answer: string, words: AnswerWord[]): MdBlock[] {
  const lines: { text: string; start: number }[] = []
  let off = 0
  for (const raw of answer.split('\n')) {
    lines.push({ text: raw, start: off })
    off += raw.length + 1
  }

  const blocks: MdBlock[] = []
  let para: MdBlock | null = null
  let codeBlock: MdBlock | null = null
  let wi = 0

  const flushPara = () => {
    if (para && para.words.length > 0) blocks.push(para)
    para = null
  }
  const hiddenWords = (lineWords: { word: AnswerWord; index: number }[]): MdWord[] =>
    lineWords.map(({ index }) => ({
      index,
      text: '',
      bold: false,
      italic: false,
      code: false,
      hidden: true,
      newline: false,
    }))

  for (const line of lines) {
    const lineEnd = line.start + line.text.length
    const lineWords: { word: AnswerWord; index: number }[] = []
    while (wi < words.length && words[wi].start < lineEnd) {
      lineWords.push({ word: words[wi], index: wi })
      wi++
    }
    const trimmed = line.text.trim()

    // Code fences open/close a verbatim block; the fence line itself is hidden.
    if (/^```/.test(trimmed)) {
      if (codeBlock) {
        codeBlock.words.push(...hiddenWords(lineWords))
        blocks.push(codeBlock)
        codeBlock = null
      } else {
        flushPara()
        codeBlock = { type: 'code', words: hiddenWords(lineWords) }
      }
      continue
    }
    if (codeBlock) {
      // The surrounding <pre> styles fenced code; no per-word inline styling.
      lineWords.forEach(({ word, index }, i) => {
        codeBlock!.words.push({
          index,
          text: word.text,
          bold: false,
          italic: false,
          code: false,
          hidden: false,
          newline: i === 0,
        })
      })
      continue
    }

    if (trimmed === '') {
      flushPara()
      continue
    }

    // Horizontal rule
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      flushPara()
      blocks.push({ type: 'hr', words: hiddenWords(lineWords) })
      continue
    }

    // Block type from the line prefix (the marker must be its own word).
    const first = lineWords[0]?.word.text ?? ''
    let type: MdBlock['type'] = 'p'
    let marker: string | undefined
    let skipFirst = false
    const heading = /^(#{1,3})\s/.exec(trimmed)
    if (heading && /^#{1,3}$/.test(first)) {
      type = `h${heading[1].length}` as MdBlock['type']
      skipFirst = true
    } else if (/^[-*+]$/.test(first) && lineWords.length > 1) {
      type = 'li'
      marker = '•'
      skipFirst = true
    } else if (/^\d{1,3}[.)]$/.test(first) && lineWords.length > 1) {
      type = 'li'
      marker = first
      skipFirst = true
    }

    const styled = styleLine(line.text, line.start, lineWords, skipFirst)

    if (type === 'p') {
      // Consecutive plain lines soft-wrap into one paragraph.
      if (!para) para = { type: 'p', words: [] }
      para.words.push(...styled)
    } else {
      flushPara()
      blocks.push({ type, marker, words: styled })
    }
  }
  flushPara()
  if (codeBlock) blocks.push(codeBlock)
  return blocks
}
