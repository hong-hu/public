import { useEffect, useState } from 'react'

/* Matches Tailwind's `sm` breakpoint: below 640px is "mobile mode" (phones,
   e.g. iPhone 14 Pro Max at 430px). Behavioral changes (single-model select,
   card list instead of table) key off this; pure styling uses sm: classes. */
const QUERY = '(max-width: 639px)'

export function useIsMobile(): boolean {
  const [mobile, setMobile] = useState(() => window.matchMedia(QUERY).matches)
  useEffect(() => {
    const mq = window.matchMedia(QUERY)
    const onChange = () => setMobile(mq.matches)
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])
  return mobile
}
