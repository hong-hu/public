/**
 * Parser for the LeetCode-style coding prompts, used by ProblemStatement.
 *
 * The raw prompts are perfectly regular (all 2869 carry "Problem:",
 * "Constraints:", "Starter code:" and "Requirements:" markers), so a
 * line-based parser splits the text into typed blocks: description
 * paragraphs, Example boxes with Input/Output/Explanation labels, bulleted
 * constraints, an optional Follow-up, the starter code, and the muted prompt
 * boilerplate (preamble + requirements). Unrecognized text falls through as
 * plain paragraphs.
 */

export interface ExampleRow {
  label: string | null // "Input" | "Output" | "Explanation"
  text: string
}

export type ProblemBlock =
  | { type: 'muted'; text: string }
  | { type: 'p'; text: string }
  | { type: 'example'; title: string; rows: ExampleRow[] }
  | { type: 'constraints'; items: string[] }
  | { type: 'followup'; text: string }
  | { type: 'code'; code: string }
  | { type: 'requirements'; items: string[] }

const EXAMPLE_RE = /^Example\s*\d*\s*:$/
const ROW_RE = /^(Input|Output|Explanation)\s*:\s*(.*)$/

export function parseProblem(raw: string): ProblemBlock[] {
  // LeetCode exports use non-breaking spaces (including on "blank" lines),
  // and some records carry literal "\\r" text at line ends.
  const lines = raw
    .replace(/\u00a0/g, ' ')
    .split('\n')
    .map((l) => l.replace(/(\\r)+\s*$/, '').trimEnd())
  const blank = (l: string | undefined) => l === undefined || l.trim() === ''
  const blocks: ProblemBlock[] = []
  let para: string[] = []
  const flush = (muted = false) => {
    if (para.length) {
      blocks.push({ type: muted ? 'muted' : 'p', text: para.join('\n') })
      para = []
    }
  }

  let i = 0
  let inPreamble = true
  while (i < lines.length) {
    const line = lines[i]
    const t = line.trim()

    // Everything before the "Problem:" marker is prompt boilerplate.
    if (inPreamble) {
      if (t === 'Problem:') {
        flush(true)
        inPreamble = false
      } else if (blank(line)) flush(true)
      else para.push(line)
      i++
      continue
    }

    if (blank(line)) {
      flush()
      i++
      continue
    }

    if (EXAMPLE_RE.test(t)) {
      flush()
      i++
      while (i < lines.length && blank(lines[i])) i++
      const rows: ExampleRow[] = []
      while (i < lines.length && !blank(lines[i])) {
        const m = ROW_RE.exec(lines[i].trim())
        if (m) rows.push({ label: m[1], text: m[2] })
        else if (rows.length > 0) rows[rows.length - 1].text += '\n' + lines[i]
        else rows.push({ label: null, text: lines[i] })
        i++
      }
      blocks.push({ type: 'example', title: t.replace(/:$/, ''), rows })
      continue
    }

    if (t === 'Constraints:') {
      flush()
      i++
      while (i < lines.length && blank(lines[i])) i++
      const items: string[] = []
      while (i < lines.length && !blank(lines[i])) {
        items.push(lines[i].trim())
        i++
      }
      blocks.push({ type: 'constraints', items })
      continue
    }

    if (/^Follow-up\s*:/.test(t)) {
      flush()
      const parts = [t.replace(/^Follow-up\s*:\s*/, '')]
      i++
      while (i < lines.length && !blank(lines[i])) {
        parts.push(lines[i].trim())
        i++
      }
      blocks.push({ type: 'followup', text: parts.join(' ') })
      continue
    }

    if (t === 'Starter code:') {
      flush()
      i++
      const code: string[] = []
      while (i < lines.length && lines[i].trim() !== 'Requirements:') {
        code.push(lines[i])
        i++
      }
      while (code.length > 0 && blank(code[code.length - 1])) code.pop()
      while (code.length > 0 && blank(code[0])) code.shift()
      blocks.push({ type: 'code', code: code.join('\n') })
      continue
    }

    if (t === 'Requirements:') {
      flush()
      i++
      const items: string[] = []
      while (i < lines.length) {
        const r = lines[i].trim()
        if (r) items.push(r.replace(/^-\s*/, ''))
        i++
      }
      blocks.push({ type: 'requirements', items })
      continue
    }

    para.push(line)
    i++
  }
  flush(inPreamble)
  return blocks
}
