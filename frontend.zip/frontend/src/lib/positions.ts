/**
 * Activation positions are token indices into the full prompt + answer
 * sequence, but the UI only renders the answer text. Per the trace format,
 * the first and last marked positions correspond to the answer's start and
 * end, and every intermediate position lands on the end of some sentence.
 * We therefore project intermediate positions linearly onto the answer and
 * snap them to the nearest sentence-final word.
 */

export interface AnswerWord {
  text: string
  start: number
}

export function splitWords(answer: string): AnswerWord[] {
  const words: AnswerWord[] = []
  const re = /\S+/g
  let m: RegExpExecArray | null
  while ((m = re.exec(answer)) !== null) {
    words.push({ text: m[0], start: m.index })
  }
  return words
}

const SENTENCE_END = /[.!?…][)"'”’\]*]*$/

/**
 * Word indices that end a line — the anchor candidates for code answers,
 * where intermediate activation positions land on line endings.
 */
export function lineEndWordIndices(answer: string, words: AnswerWord[]): number[] {
  const ends: number[] = []
  for (let i = 0; i < words.length - 1; i++) {
    const between = answer.slice(words[i].start + words[i].text.length, words[i + 1].start)
    if (between.includes('\n')) ends.push(i)
  }
  return ends
}

/**
 * Map each activation position to a word index in the answer. Intermediate
 * positions snap to the nearest anchor word — sentence-final words by
 * default, or the given anchors (e.g. line-final words for code).
 */
export function mapPositionsToWords(
  positions: number[],
  words: AnswerWord[],
  anchors?: number[],
): Map<number, number> {
  const result = new Map<number, number>()
  if (positions.length === 0 || words.length === 0) return result

  const sorted = [...positions].sort((a, b) => a - b)
  const first = sorted[0]
  const last = sorted[sorted.length - 1]
  const lastWord = words.length - 1

  result.set(first, 0)
  if (sorted.length === 1) return result
  result.set(last, lastWord)

  const sentenceEnds = (
    anchors ?? words.map((w, i) => (SENTENCE_END.test(w.text) ? i : -1))
  ).filter((i) => i > 0 && i < lastWord)

  const span = last - first
  let prevIdx = 0
  for (let k = 1; k < sorted.length - 1; k++) {
    const target = Math.round(((sorted[k] - first) / span) * lastWord)
    // Nearest sentence end that keeps markers strictly increasing.
    const candidates = sentenceEnds.filter((i) => i > prevIdx)
    let idx: number
    if (candidates.length > 0) {
      idx = candidates.reduce((best, i) => (Math.abs(i - target) < Math.abs(best - target) ? i : best))
    } else {
      idx = Math.min(Math.max(target, prevIdx + 1), lastWord - 1)
    }
    result.set(sorted[k], idx)
    prevIdx = idx
  }
  return result
}
