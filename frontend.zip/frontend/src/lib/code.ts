import type { AnswerWord } from './positions'

/**
 * Word-level Python layout for the coding Observed Generation view.
 *
 * Same contract as markdown.ts: the answer streams word by word and activation
 * highlights are keyed by word index into `splitWords(answer)`, so instead of a
 * real syntax highlighter we annotate the existing word array — indices never
 * change, only how each word is displayed. Granularity is one class per word
 * (a word like `enumerate(nums):` is classed by its leading identifier).
 */

export type CodeClass = 'kw' | 'builtin' | 'str' | 'com' | 'num' | 'def' | null

/** Syntax colors for the word-level Python classes, shared by the Observed
    Generation code view and the problem statement's starter-code block. */
export const CODE_COLORS: Record<string, string> = {
  kw: 'text-purple-400',
  def: 'text-sky-300',
  builtin: 'text-cyan-300',
  str: 'text-amber-300/90',
  com: 'text-zinc-500 italic',
  num: 'text-orange-300',
}

export interface CodeWord {
  /** Index into the original splitWords() array — highlight keys stay valid. */
  index: number
  text: string
  /** Exact whitespace between the previous word (or line start) and this one. */
  pre: string
  cls: CodeClass
}

export interface CodeLine {
  /** 1-based line number in the answer. */
  no: number
  words: CodeWord[]
}

const KEYWORDS = new Set(
  (
    'False None True and as assert async await break class continue def del elif else except finally ' +
    'for from global if import in is lambda nonlocal not or pass raise return try while with yield self cls match case'
  ).split(' '),
)

const BUILTINS = new Set(
  (
    'abs all any ascii bin bool bytearray bytes callable chr classmethod compile complex delattr dict dir divmod ' +
    'enumerate eval exec filter float format frozenset getattr globals hasattr hash help hex id input int isinstance ' +
    'issubclass iter len list locals map max memoryview min next object oct open ord pow print property range repr ' +
    'reversed round set setattr slice sorted staticmethod str sum super tuple type vars zip'
  ).split(' '),
)

interface Range {
  start: number
  end: number
}

/**
 * One pass over the whole answer marking string and comment ranges
 * (absolute char offsets), handling ' " triple quotes and # to end of line.
 */
function stringAndCommentRanges(text: string): { str: Range[]; com: Range[] } {
  const str: Range[] = []
  const com: Range[] = []
  let i = 0
  while (i < text.length) {
    const c = text[i]
    if (c === '#') {
      let j = text.indexOf('\n', i)
      if (j === -1) j = text.length
      com.push({ start: i, end: j })
      i = j
      continue
    }
    if (c === '"' || c === "'") {
      const triple = text.slice(i, i + 3) === c.repeat(3)
      const quote = triple ? c.repeat(3) : c
      const start = i
      i += quote.length
      while (i < text.length) {
        if (text[i] === '\\') {
          i += 2
          continue
        }
        if (text.startsWith(quote, i)) {
          i += quote.length
          break
        }
        // Unterminated single-quoted strings stop at the line break.
        if (!triple && text[i] === '\n') break
        i++
      }
      str.push({ start, end: i })
      continue
    }
    i++
  }
  return { str, com }
}

/** The leading identifier or number of a word, e.g. "enumerate(nums):" -> "enumerate". */
const LEAD_TOKEN = /^[A-Za-z_][A-Za-z0-9_]*|^\d[\d_]*(\.[\d_]+)?/

export function parseCodeLines(answer: string, words: AnswerWord[]): CodeLine[] {
  const { str, com } = stringAndCommentRanges(answer)
  const inRanges = (ranges: Range[], p: number) => ranges.some((r) => p >= r.start && p < r.end)

  const lines: CodeLine[] = []
  let current: CodeLine = { no: 1, words: [] }
  lines.push(current)
  let prevEnd = 0 // char offset right after the previous word
  let prevDefKeyword = false

  for (let i = 0; i < words.length; i++) {
    const w = words[i]
    const gap = answer.slice(prevEnd, w.start)
    const nl = gap.lastIndexOf('\n')
    if (nl !== -1) {
      // Emit one CodeLine per newline so blank lines keep their numbers.
      const breaks = gap.match(/\n/g)!.length
      for (let b = 0; b < breaks; b++) {
        current = { no: current.no + 1, words: [] }
        lines.push(current)
      }
    }
    const pre = nl === -1 ? gap : gap.slice(nl + 1)

    let cls: CodeClass = null
    if (inRanges(com, w.start)) cls = 'com'
    else if (inRanges(str, w.start)) cls = 'str'
    else if (prevDefKeyword) cls = 'def'
    else {
      const lead = LEAD_TOKEN.exec(w.text)?.[0]
      if (lead !== undefined) {
        if (/^\d/.test(lead)) cls = 'num'
        else if (KEYWORDS.has(lead)) cls = 'kw'
        else if (BUILTINS.has(lead)) cls = 'builtin'
      }
    }
    prevDefKeyword = cls === 'kw' && (w.text === 'def' || w.text === 'class')

    current.words.push({ index: i, text: w.text, pre, cls })
    prevEnd = w.start + w.text.length
  }
  return lines
}
