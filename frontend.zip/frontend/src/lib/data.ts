import type { DatasetInfo, ModelBundle, ModelInfo, PromptRow, VerdictInfo } from './types'

const base = import.meta.env.BASE_URL

async function fetchJson<T>(path: string): Promise<T> {
  const res = await fetch(`${base}${path}`)
  if (!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`)
  return res.json()
}

let datasetsPromise: Promise<DatasetInfo[]> | null = null
export function loadDatasets(): Promise<DatasetInfo[]> {
  datasetsPromise ??= fetchJson<DatasetInfo[]>('data/datasets.json')
  return datasetsPromise
}

const promptsCache = new Map<string, Promise<PromptRow[]>>()
export function loadPrompts(datasetKey = 'auditing'): Promise<PromptRow[]> {
  let p = promptsCache.get(datasetKey)
  if (!p) {
    p = fetchJson<PromptRow[]>(`data/${datasetKey}/prompts.json`)
    promptsCache.set(datasetKey, p)
  }
  return p
}

const modelsCache = new Map<string, Promise<ModelInfo[]>>()
export function loadModels(datasetKey = 'auditing'): Promise<ModelInfo[]> {
  let p = modelsCache.get(datasetKey)
  if (!p) {
    p = fetchJson<ModelInfo[]>(`data/${datasetKey}/models.json`)
    modelsCache.set(datasetKey, p)
  }
  return p
}

const verdictsCache = new Map<string, Promise<Record<string, VerdictInfo>>>()
/** Verdict-only bundle — much smaller than the full trace bundle. */
export function loadVerdicts(datasetKey: string, modelKey: string): Promise<Record<string, VerdictInfo>> {
  const cacheKey = `${datasetKey}/${modelKey}`
  let p = verdictsCache.get(cacheKey)
  if (!p) {
    p = fetchJson<Record<string, VerdictInfo>>(`data/${datasetKey}/verdicts_${modelKey}.json`)
    verdictsCache.set(cacheKey, p)
  }
  return p
}

const bundleCache = new Map<string, Promise<ModelBundle>>()
export function loadModelBundle(datasetKey: string, modelKey: string): Promise<ModelBundle> {
  const cacheKey = `${datasetKey}/${modelKey}`
  let p = bundleCache.get(cacheKey)
  if (!p) {
    p = fetchJson<ModelBundle>(`data/${datasetKey}/model_${modelKey}.json`)
    bundleCache.set(cacheKey, p)
  }
  return p
}
