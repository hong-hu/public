import { useEffect, useState } from 'react'
import { Navigation, type Tab } from './components/Navigation'
import { DatasetTab } from './components/DatasetTab'
import { loadDatasets } from './lib/data'
import type { DatasetInfo } from './lib/types'

export default function App() {
  const [tab, setTab] = useState<Tab>('coding')
  const [datasets, setDatasets] = useState<DatasetInfo[]>([
    { key: 'coding', label: 'Coding', kind: 'coding' },
    { key: 'coding_cot', label: 'Coding CoT', kind: 'coding', cot: true },
    { key: 'auditing', label: 'Safety' },
    { key: 'auditing_cot', label: 'Safety CoT', cot: true },
  ])

  useEffect(() => {
    loadDatasets()
      .then((ds) => {
        if (ds && ds.length > 0) {
          setDatasets(ds)
          setTab((cur) => (!ds.some((d) => d.key === cur) ? ds[0].key : cur))
        }
      })
      .catch(() => {})
  }, [])

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation active={tab} onChange={setTab} datasets={datasets} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-24">
        <DatasetTab
          key={tab}
          datasetKey={tab}
          kind={datasets.find((d) => d.key === tab)?.kind ?? 'auditing'}
          cot={datasets.find((d) => d.key === tab)?.cot ?? false}
        />
      </main>
      <footer className="border-t border-white/5 light:border-black/5 py-8 text-center text-xs text-muted-foreground/60">
        Transparent Minds · MIDS W210 Capstone · Natural Language Autoencoder
      </footer>
    </div>
  )
}
